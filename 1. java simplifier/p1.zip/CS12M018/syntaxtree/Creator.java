package syntaxtree;

public class Creator{
	public static Type createTypeFor(String typeName){
		return new Type(new NodeChoice(new NodeToken(typeName)));
	}
	
	public static Identifier createIdentifierFor(String identifierName){
		return new Identifier(new NodeToken(identifierName));
	}
	
	public static Expression createExpressionFor(String expr){
		return new Expression(new NodeChoice(new NodeToken(expr)));
	}
	
	public static VarDeclaration createVarDeclarationFor(Type tp, String identifier){
		return new VarDeclaration(tp, Creator.createIdentifierFor(identifier));
	}
	
	public static FormalParameter createFormalParameterFor(Type tp, String identifier){
		return new FormalParameter(tp, Creator.createIdentifierFor(identifier));
	}
	
	public static FormalParameterList addToFormalParameterList(FormalParameterList list, FormalParameter param){
		if(list == null){
			list = new FormalParameterList(param, new NodeListOptional());
		} else if(list.f0 == null){
			list.f0 = param;
		} else {
			list.f1.addNode(new FormalParameterRest(param));
		}
		
		return list;	
	}
	
	public static ExpressionList addToExpressionList(ExpressionList list, Expression expr){
		if(list == null){
			list = new ExpressionList(expr, new NodeListOptional());
		} else if(list.f0 == null){
			list.f0 = expr;
		} else {
			list.f1.addNode(new ExpressionRest(expr));
		}
		
		return list;
	}
	
	public static Type getTypeOfExpression(Expression expr){
		Node nd = expr.f0.choice;
		
		if((nd instanceof AndExpression ) || (nd instanceof CompareExpression)){
			return Creator.createTypeFor("boolean");
		} else if((nd instanceof PlusExpression) || (nd instanceof MinusExpression) || (nd instanceof TimesExpression) || (nd instanceof ArrayLength) || (nd instanceof ArrayLookup)){		
			return Creator.createTypeFor("int");
		} else if(nd instanceof PrimaryExpression){
			Node nd2 = ((PrimaryExpression) nd).f0.choice;
			
			if( (nd2 instanceof TrueLiteral) || (nd2 instanceof FalseLiteral) || (nd2 instanceof NotExpression)){
				return Creator.createTypeFor("boolean");
			} else if( nd2 instanceof IntegerLiteral){
				return Creator.createTypeFor("int");
			}
		
		}
		
		System.err.println("Error !! Type could not be determined for expr \'"+expr.toString()+"\'");
		return Creator.createTypeFor("int");
	}
}