package syntaxtree;

public class WrapperEnclosure{
	public static Type getWrapperFor(String type){
	
			//System.out.println("Matching for "+type);
			if(type.equals("boolean")){
				return new Type(new NodeChoice(new NodeToken("Boolean")));
			}else if(type.equals("int")){
				return new Type(new NodeChoice(new NodeToken("Integer")));
			} else if(type.equals("int[]")){
				return new Type(new NodeChoice(new ArrayType()));
			} else {
				// identifier --  a class name
				return new Type(new NodeChoice(new NodeToken(type)));
			}
	}
}