import syntaxtree.*;
import visitor.*;
import java.io.*;

public class Main {
   public static void main(String [] args) {
      /*
	  System.out.println("ARgs length is: "+args.length);
	  System.out.println("Hello");
	  if(args.length != 4){
	 /* System.out.println(args[0]);
		System.out.println("ARgs length is: "+args.length);
	  
		System.err.println("!!Usage Info ::--");
		System.err.println("java Main < ip_file.java > op_file.java");
		return;
	  }
	  String ipFile, opFile;
	  
	  if(args[0].equals(">") && args[2].equals("<")){
		ipFile = args[1];
		opFile = args[3];
	  }else if(args[0].equals("<") && args[2].equals(">")){
		ipFile = args[3];
		opFile = args[1];
	  } else {
		System.err.println("Usage Info ::--");
		System.err.println("java Main < ip_file.java > op_file.java");
		return;
	  }
	  */
	  try {
         Node root = new MiniJavaParser(System.in).Goal();
         //System.out.println("Program parsed successfully");
		 GJNoArguDepthFirst first =new GJNoArguDepthFirst();
		 first.setOut(System.out);
         root.accept(first); // Your assignment part is invoked here.
      }
      catch (ParseException e) {
         System.out.println(e.toString());
      }catch(Exception e){
		e.printStackTrace();
	  }
   }
}