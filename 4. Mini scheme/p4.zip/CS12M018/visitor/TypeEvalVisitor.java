package visitor;

import java.util.Enumeration;
import java.util.Vector;

import store.Store;
import store.Type;
import syntaxtree.Application;
import syntaxtree.Assignment;
import syntaxtree.Declaration;
import syntaxtree.Expression;
import syntaxtree.FalseLiteral;
import syntaxtree.Goal;
import syntaxtree.Identifier;
import syntaxtree.IfExpression;
import syntaxtree.IntegerLiteral;
import syntaxtree.LetExpression;
import syntaxtree.Node;
import syntaxtree.NodeList;
import syntaxtree.NodeListOptional;
import syntaxtree.NodeOptional;
import syntaxtree.NodeSequence;
import syntaxtree.NodeToken;
import syntaxtree.PlusExpression;
import syntaxtree.ProcedureExp;
import syntaxtree.RecDeclaration;
import syntaxtree.RecExpression;
import syntaxtree.TrueLiteral;

public class TypeEvalVisitor implements GJNoArguVisitor<Type> {
	//
	// Auto class visitors--probably don't need to be overridden.
	//
	public Type visit(NodeList n) {
		return visit(n.elements());
	}

	public Type visit(NodeListOptional n) {
		if ( n.present() ) {
			return visit(n.elements());
		}
		else{
			return null;
		}
	}


	public Type visit(NodeOptional n) {
		if ( n.present() )
			return n.node.accept(this);
		else
			return null;
	}

	public Type visit(NodeSequence n) {
		return visit(n.elements());
	}

	public Type visit(NodeToken n) { return null; }


	private Type visit(Enumeration<Node> e){
		Type _ret=new Type();
		int _count=0;
		for ( ; e.hasMoreElements(); ) {
			Type t1 = e.nextElement().accept(this);

			Type temp = _ret;
			while(temp.getRet() != null){
				temp = temp.getRet();
			}
			temp.setRet(t1);
			_count++;
		}
		return _ret;
	}
	//
	// User-generated visitor methods below
	//

	/**
	 * f0 -> Expression()
	 * f1 -> <EOF>
	 */
	@Override
	public Type visit(Goal n) {
		Type tp = n.f0.accept(this);
		return tp;
	}

	/**
	 * f0 -> IntegerLiteral()
	 *       | TrueLiteral()
	 *       | FalseLiteral()
	 *       | PlusExpression()
	 *       | IfExpression()
	 *       | LetExpression()
	 *       | Identifier()
	 *       | Assignment()
	 *       | ProcedureExp()
	 *       | Application()
	 *       | RecExpression()
	 */
	@Override
	public Type visit(Expression n) {
		return n.f0.accept(this);
	}

	/**
	 * f0 -> <INTEGER_LITERAL>
	 */
	@Override
	public Type visit(IntegerLiteral n) {
		return Store.intType;
	}


	/**
	 * f0 -> "#t"
	 */

	@Override
	public Type visit(TrueLiteral n) {		
		return Store.boolType;
	}

	/**
	 * f0 -> "#f"
	 */

	@Override
	public Type visit(FalseLiteral n) {
		return Store.boolType;
	}

	/**
	 * f0 -> "("
	 * f1 -> "+"
	 * f2 -> Expression()
	 * f3 -> Expression()
	 * f4 -> ")"
	 */

	@Override
	public Type visit(PlusExpression n) {
		Type tp1 = n.f2.accept(this);
		Type tp2 = n.f3.accept(this);

		tp1.setRet(Store.intType);
		tp2.setRet(Store.intType);

		return new Type(new Type(Store.intType, Store.intType), Store.intType);
	}

	/**
	 * f0 -> "("
	 * f1 -> "if"
	 * f2 -> Expression()
	 * f3 -> Expression()
	 * f4 -> Expression()
	 * f5 -> ")"
	 */
	//1. tp2 and tp3 must remain the same
	//2. tp1 must be a boolean
	@Override
	public Type visit(IfExpression n) {
		Type tp1 = n.f2.accept(this);
		Type tp2 = n.f3.accept(this);
		Type tp3 = n.f4.accept(this);

		tp1.setRet(Store.boolType);

		return tp2;
	}

	/**
	 * f0 -> "("
	 * f1 -> "let"
	 * f2 -> "("
	 * f3 -> ( Declaration() )*
	 * f4 -> ")"
	 * f5 -> Expression()
	 * f6 -> ")"
	 */
	@Override
	public Type visit(LetExpression n) {
		Type tp1 = n.f3.accept(this);
		Type tp2 = n.f5.accept(this);
		
		return tp2;
	}

	/**
	 * f0 -> <IDENTIFIER>
	 */

	@Override
	public Type visit(Identifier n) {
		return Store.addIdentifier(n.f0.tokenImage);
	}

	/**
	 * f0 -> "("
	 * f1 -> "set!"
	 * f2 -> Identifier()
	 * f3 -> Expression()
	 * f4 -> ")"
	 */
	@Override
	public Type visit(Assignment n) {
		Type tp1 = n.f2.accept(this);
		Type tp2 = n.f3.accept(this);

		Store.updateType(tp1, tp2.getRet());

		return tp2;
	}
	/**
	 * f0 -> "("
	 * f1 -> "lambda"
	 * f2 -> "("
	 * f3 -> ( Identifier() )*
	 * f4 -> ")"
	 * f5 -> Expression()
	 * f6 -> ")"
	 */
	@Override
	public Type visit(ProcedureExp n) {
		Type tp1 = n.f3.accept(this);
		Type tp2 = n.f5.accept(this);

		// dont' touch
		return new Type(tp1, tp2);
	}

	/**
	 * f0 -> "("
	 * f1 -> Expression()
	 * f2 -> ( Expression() )*
	 * f3 -> ")"
	 */
	@Override
	public Type visit(Application n) {
		// TODO Auto-generated method stub
		Type tp1 = n.f1.accept(this);
		Type tp2 = n.f2.accept(this);

		if(tp1.isPrimary()) {
			Store.updateType(tp1, new Type(tp2, Store.addIdentifier("hell")));
		} else {
			updateRef(tp1, n.f2.nodes);
		}

		
		// with this 2nd case works..
		return tp1.getRet();
	}

	private void updateRef(Type tp, Vector<Node> node) {
		for(int i=0 ; i<node.size() ; ++i){
			Node nd = ((Expression)node.get(i)).f0.choice;
			
			if(nd instanceof Identifier){
				String name = ((Identifier) nd).f0.tokenImage;
				int temp = i;
				Type tempTp = tp;
				while(temp >= 0 && tempTp != null){
					tempTp = tempTp.getArg();
					--temp;
				}
				
				if(tempTp != null){
					Store.updateType(Store.getType(name), tempTp);
				}
			}
		}
	}

	/**
	 * f0 -> "("
	 * f1 -> "letrec"
	 * f2 -> "("
	 * f3 -> ( RecDeclaration() )*
	 * f4 -> ")"
	 * f5 -> Expression()
	 * f6 -> ")"
	 */

	@Override
	public Type visit(RecExpression n) {
		Type tp1 = n.f3.accept(this);
		Type tp2 = n.f5.accept(this);
		return tp2.getRet();
	}
	
	/**
	 * f0 -> "("
	 * f1 -> Identifier()
	 * f2 -> Expression()
	 * f3 -> ")"
	 */
	@Override
	public Type visit(Declaration n) {
		Type tp1 = n.f1.accept(this);
		Type tp2 = n.f2.accept(this);

		if(n.f2.f0.choice instanceof ProcedureExp){
			Store.updateType(tp1, tp2);
		}else {
			Store.updateType(tp1, tp2.getRet());
		}
		return Store.voidType;
	}

	/**
	 * f0 -> "("
	 * f1 -> Identifier()
	 * f2 -> ProcedureExp()
	 * f3 -> ")"
	 */	
	@Override
	public Type visit(RecDeclaration n) {
		Type tp1 = n.f1.accept(this);
		Type tp2 = n.f2.accept(this);

		Store.updateType(tp1, tp2);

		return Store.voidType;
	}
}