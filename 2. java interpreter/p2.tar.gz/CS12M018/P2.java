import java.io.File;
import java.io.FileInputStream;

import syntaxtree.Node;
import visitor.StructureExtractorGJVisitor;

public class P2{
	public static void main(String[] args){
		try {
			java.util.Scanner read = new java.util.Scanner(System.in);
			new MicroJavaParser(new FileInputStream(new File(read.nextLine().trim())));
			Node root = MicroJavaParser.Goal();

			root.accept(new StructureExtractorGJVisitor());
		}
		catch (ParseException e) {
			System.out.println(e.toString());
		}catch(Exception e){
			e.printStackTrace();
		}
	}
}