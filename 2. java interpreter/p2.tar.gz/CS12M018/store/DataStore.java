package store;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import syntaxtree.ClassDeclaration;
import syntaxtree.ClassExtendsDeclaration;
import syntaxtree.MainClass;
import syntaxtree.MethodDeclaration;
import syntaxtree.Node;
import syntaxtree.VarDeclaration;
import visitor.ToStringGJVisitor;

public class DataStore {

	// it can be a class or classExtends
	/*
	 * ClassMap includes anything from
	 * @ClassDeclaration
	 * @ClassExtendsDeclaration
	 * @MainClass
	 */
	public static void addToClassMap(String name, Node cls){
		//System.out.println("Adding class: "+name);

		classMap.put(name, cls);

		Iterator<Node> methodIter = null;
		Iterator<Node> varIter = null;
		if(cls instanceof ClassDeclaration){
			methodIter = ((ClassDeclaration) cls).f4.nodes.iterator();
			varIter = ((ClassDeclaration) cls).f3.nodes.iterator();
		}

		else if(cls instanceof ClassExtendsDeclaration){
			methodIter = ((ClassExtendsDeclaration) cls).f6.nodes.iterator();
			varIter = ((ClassExtendsDeclaration) cls).f5.nodes.iterator();
		}

		else if(cls instanceof MainClass){
			//addToMethodMap(cls, null);
			//TODO: Not sure how to handle this case..
		}

		if(methodIter != null){
			while(methodIter.hasNext()){
				Node method = methodIter.next();
				addToMethodMap(cls, method);
			}
		}

		if(varIter != null){
			while(varIter.hasNext()){
				Node var = varIter.next();

				if(var instanceof VarDeclaration){

					//		System.out.println(((VarDeclaration) var).f1.accept(new ToStringGJVisitor())+ 
					//				" has var "+((VarDeclaration) var).f0.f0.choice.accept(new ToStringGJVisitor()));
				}

			}
		}
	}

	public static void addToMethodMap(Node cls, Node method){
		String className = null, methodName=null;

		if(cls instanceof ClassDeclaration){
			className = ((ClassDeclaration) cls).f1.accept(new ToStringGJVisitor());
		}

		if(cls instanceof ClassExtendsDeclaration){
			className = ((ClassExtendsDeclaration) cls).f1.accept(new ToStringGJVisitor());
		}

		if(method instanceof MethodDeclaration){
			methodName = ((MethodDeclaration) method).f2.accept(new ToStringGJVisitor());

			Iterator<Node> iter = ((MethodDeclaration) method).f7.nodes.iterator();
			while(iter.hasNext()){
				Node var = iter.next();

				if(var instanceof VarDeclaration){

					//	System.out.println("Method "+methodName+" has var "+((VarDeclaration) var).f1.accept(new ToStringGJVisitor())+
					//			" of type "+((VarDeclaration) var).f0.f0.choice.accept(new ToStringGJVisitor()));
				}

			}
		}


		//	System.out.println("Class = "+className+", method = "+methodName);

		List<Node> list = methodMap.get(cls);
		if(list == null){
			list = new ArrayList<Node>();
			methodMap.put(cls, list);
		}

		list.add(method);
	}


	public static List<Node> getMethodList(String cls){
		return readAllMethodsFrom(classMap.get(cls));
	}

	private static List<Node> readAllMethodsFrom(Node nd){
		List<Node> list = new ArrayList<Node>();

		if(nd == null){

		}
		else if(nd instanceof ClassExtendsDeclaration){
			ClassExtendsDeclaration cls = (ClassExtendsDeclaration) nd;
			Iterator<Node> iter = cls.f6.nodes.iterator();
			while(iter.hasNext()){
				list.add(iter.next());
			}

			iter = readAllMethodsFrom(DataStore.store.getClass(cls.f3.accept(ToStringGJVisitor.visitor))).iterator();
			while(iter.hasNext()){
				Node current = iter.next();
				boolean isTrue = false;
				for(Node currentNode : list){
					String currentName = ((MethodDeclaration)current).f2.accept(ToStringGJVisitor.visitor);
					String currentNodeName = ((MethodDeclaration)currentNode).f2.accept(ToStringGJVisitor.visitor);

					if(currentName.equals(currentNodeName)){
						isTrue = true;
						break;
					}

				}// end of for loop

				if(!isTrue){
					list.add(current);
				}
			} // end of iter
		}
		else if(nd instanceof ClassDeclaration){
			ClassDeclaration cls = (ClassDeclaration) nd;
			Iterator<Node> iter = cls.f4.nodes.iterator();
			while(iter.hasNext()){
				list.add(iter.next());
			}
		}

		return list;
	}

	public static Node getMethod(String cls, String methodName){

		Iterator<Node> methodList = getMethodList(cls).iterator();

		while(methodList.hasNext()){
			MethodDeclaration method = (MethodDeclaration) methodList.next();

			if(method.f2.accept(ToStringGJVisitor.visitor).equals(methodName)){
				return method;
			}

		}

		return null;
	}

	public Node getClass(String clsName){
		return classMap.get(clsName);
	}

	private static Map<String, Node> classMap = new HashMap<String, Node>();
	private static Map<Node, List<Node>> methodMap = new HashMap<Node, List<Node>>();	

	public static final DataStore store = new DataStore();

}
