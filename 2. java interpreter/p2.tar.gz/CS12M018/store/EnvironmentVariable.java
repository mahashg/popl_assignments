package store;

import java.util.List;

import syntaxtree.ArrayType;
import syntaxtree.BooleanType;
import syntaxtree.Identifier;
import syntaxtree.IntegerType;
import syntaxtree.NodeChoice;
import syntaxtree.NodeToken;
import syntaxtree.Type;
import visitor.ToStringGJVisitor;

public class EnvironmentVariable {
	public String name;
	public Type type;
	//public Node value;
	
	public int intValue;
	public boolean booleanValue;
	public int[] arrayValue;
	public List<EnvironmentVariable> objectValue;

	public EnvironmentVariable(String name, Type type) {
		super();
		this.name = name;
		this.type = new Type(new NodeChoice(type.f0.choice));
		
		init();
	}
	
	private void init() {
		this.intValue = 0;
		this.booleanValue = false;
		this.arrayValue = null;
		this.objectValue = null;
		
	}

	public EnvironmentVariable(EnvironmentVariable vie) {
		this.name = new String(vie.name);
		this.type = new Type(new NodeChoice(vie.type.f0.choice));
	
		this.intValue = vie.intValue;
		this.booleanValue = vie.booleanValue;
		this.arrayValue = (vie.arrayValue == null ? null : vie.arrayValue.clone());
		this.objectValue = vie.objectValue;
		/*this.objectValue = new ArrayList<EnvironmentVariable>();
		if(vie.objectValue != null && !vie.objectValue.isEmpty()){
			for(EnvironmentVariable var : vie.objectValue){
				this.objectValue.add(new EnvironmentVariable(var));
			}
		}*/
		
	}
	
	public int readAsInt(){
		return intValue;
		//Integer.parseInt(((IntegerLiteral)value).f0.tokenImage);
	}
	
	public boolean readAsBoolean(){
		return booleanValue;
		//Boolean.parseBoolean(((BooleanType)value).f0.tokenImage);
	}
	
	public int[] readAsArray(){
		return arrayValue;
	}
	
	public List<EnvironmentVariable> readAsObject(){
		return objectValue;
	}
	
	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append(this.name+" = ");
		
		if(this.type.f0.choice instanceof IntegerType){
			sb.append(this.intValue);
		} else if(this.type.f0.choice instanceof BooleanType){
			sb.append(this.booleanValue);
		} else if(this.type.f0.choice instanceof ArrayType){
			sb.append("[");
			if(arrayValue != null){
				for(int i=0 ; i<arrayValue.length ; ++i){
					sb.append(arrayValue[i]+", ");
				}
			}
			sb.append("]");
			
		} else if((this.type.f0.choice instanceof Identifier)
					|| (this.type.f0.choice instanceof NodeToken)){
			sb.append("{");
			if(objectValue != null){
				for(EnvironmentVariable _varEnv : objectValue){
					sb.append(_varEnv.toString()+", ");
				}
			}
			sb.append("}");
			
		} else {
			
			System.err.println("No type found for: "+this.name+" of type "+this.type.f0.choice.accept(ToStringGJVisitor.visitor));
			System.err.println("type found was: "+this.type.f0.choice.getClass());
		}
		sb.append("\n");
		return sb.toString();
	}
	
}