package store;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import syntaxtree.ArrayType;
import syntaxtree.BooleanType;
import syntaxtree.ClassDeclaration;
import syntaxtree.ClassExtendsDeclaration;
import syntaxtree.Expression;
import syntaxtree.ExpressionList;
import syntaxtree.ExpressionRest;
import syntaxtree.FormalParameter;
import syntaxtree.FormalParameterList;
import syntaxtree.FormalParameterRest;
import syntaxtree.IntegerType;
import syntaxtree.Node;
import syntaxtree.NodeChoice;
import syntaxtree.NodeOptional;
import syntaxtree.NodeToken;
import syntaxtree.Type;
import syntaxtree.VarDeclaration;
import visitor.StructureExtractorGJVisitor;
import visitor.ToStringGJVisitor;

public class Utility {

	/*
	 * Given two node optional values
	 * 1. for parameter declaration as defined in method declaration
	 * 2. for parameter values as expression.
	 * 
	 * it does one to one mapping and creates a list of environment variables
	 */
	public static List<EnvironmentVariable> createEnvironmentVariableMappingFor
	(NodeOptional paramDeclNodeOptional, NodeOptional paramExprNodeOptional, Environment env, StructureExtractorGJVisitor visitor) {

		// each should be a valid value
		if(paramDeclNodeOptional.node == null || paramExprNodeOptional.node == null){
			return null;
		}

		if((paramDeclNodeOptional.node instanceof FormalParameterList) &&
				(paramExprNodeOptional.node instanceof ExpressionList)){

			FormalParameterList paramList = (FormalParameterList) paramDeclNodeOptional.node;
			ExpressionList exprList = (ExpressionList) paramExprNodeOptional.node;

			if(paramList.f1.size() != exprList.f1.size()){
				// arguments size does not matches
				System.err.println("Error in Utility.createEnvVarMapping method, args size do not match..");
				System.err.println("param size "+(paramList.f1.size()+1)+" and expr size "+(exprList.f1.size()+1));
			}

			List<EnvironmentVariable> var = new ArrayList<EnvironmentVariable>();
			var.add(createEnvironmentVariable(paramList.f0, exprList.f0, env, visitor));

			Iterator<Node> formalIter = paramList.f1.nodes.iterator();
			Iterator<Node> exprIter = exprList.f1.nodes.iterator();

			while(formalIter.hasNext()){
				FormalParameter formal = ((FormalParameterRest)formalIter.next()).f1;
				Expression expr = ((ExpressionRest) exprIter.next()).f1;

				var.add(createEnvironmentVariable(formal, expr, env, visitor));
			}

			return var;
		}
		return null;
	}

	public static EnvironmentVariable createEnvironmentVariable(FormalParameter decl, Expression expr,
			Environment env, StructureExtractorGJVisitor visitor){

		EnvironmentVariable var = new EnvironmentVariable
				(decl.f1.accept(ToStringGJVisitor.visitor), decl.f0);

		EnvironmentVariable _ret = visitor.visit(expr, env);

		if(decl.f0.f0.choice instanceof IntegerType){
			var.intValue = _ret.intValue;
		}
		else if(decl.f0.f0.choice instanceof BooleanType){
			var.booleanValue = _ret.booleanValue;
		}
		else if(decl.f0.f0.choice instanceof ArrayType){
			var.arrayValue = _ret.arrayValue;
		}
		else {
			var.objectValue = _ret.objectValue;
			var.type = _ret.type;
		}

		//		System.out.println("Creating formal params.. "+decl.f1.accept(ToStringGJVisitor.visitor)+
		//				" of type "+decl.f0.accept(ToStringGJVisitor.visitor));

		return var;
	}

	public static EnvironmentVariable createEnvironmentVariable(VarDeclaration var) {

		EnvironmentVariable variable = new EnvironmentVariable(var.f1.accept(ToStringGJVisitor.visitor), var.f0);

		return variable;
	}

	public static EnvironmentVariable createObjectOfType(String clsName) {

		//TODO: check if nd is null
		Node nd = DataStore.store.getClass(clsName);
		List<EnvironmentVariable> list = readEnvVariablesFrom(nd);

		String objName = "__var__"+System.nanoTime();
		EnvironmentVariable var = new EnvironmentVariable(objName, new Type(new NodeChoice(new NodeToken(clsName))));
		var.objectValue = list;

		return var;

	}

	private static List<EnvironmentVariable> readEnvVariablesFrom(Node nd) {

		List<EnvironmentVariable> list = new ArrayList<EnvironmentVariable>();
		//System.out.println(nd.getClass());
		if(nd == null){

		}

		else if(nd instanceof ClassExtendsDeclaration){
			
			ClassExtendsDeclaration ext = (ClassExtendsDeclaration) nd;
			Iterator<Node> iter = ext.f5.nodes.iterator();

			while(iter.hasNext()){
				VarDeclaration var = (VarDeclaration)iter.next();
				EnvironmentVariable enIter = new EnvironmentVariable(var.f1.accept(ToStringGJVisitor.visitor), var.f0);
				list.add(enIter);
			}

			// read from its super and super to super and so on..
			Iterator<EnvironmentVariable> appendListIter = readEnvVariablesFrom(DataStore.store.getClass(ext.f3.accept(ToStringGJVisitor.visitor))).iterator();
			while(appendListIter.hasNext()){
				list.add(appendListIter.next());
			}
		} 

		else if(nd instanceof ClassDeclaration){
			Iterator<Node> iter = ((ClassDeclaration) nd).f3.nodes.iterator();

			while(iter.hasNext()){
				VarDeclaration var = (VarDeclaration)iter.next();
				EnvironmentVariable enIter = new EnvironmentVariable(var.f1.accept(ToStringGJVisitor.visitor), var.f0);
				list.add(enIter);
			}
		}
		return list;
	}

	public static EnvironmentVariable getMemberOf(EnvironmentVariable object, String fldName) {

		if(object.objectValue != null){
			List<EnvironmentVariable> objList = object.objectValue;
			if(objList != null && !objList.isEmpty()){
				for(EnvironmentVariable var : objList){
					if(var.name.equals(fldName)){
						return  var;
					}
				}
			}
		}

		else if(object.type.f0.choice instanceof ArrayType){
			if(fldName.equals("length")){
				int size=0;
				if(object.arrayValue != null){
					size = object.arrayValue.length;
				}
				EnvironmentVariable var = new EnvironmentVariable("length", new Type(new NodeChoice(new IntegerType())));
				var.intValue = size;

				return var;
			}
		}

		System.err.println(" could not find.. "+fldName);
		return null;
	}

}
