package store;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class Environment {
	List<EnvironmentVariable> varMap;
	EnvironmentVariable thisVariable;
	
	public Environment() {
		 varMap = new ArrayList<EnvironmentVariable>();
	}
	
	public Environment(Environment oldOne){
		this();
		Iterator<EnvironmentVariable> iter = oldOne.varMap.iterator();
		
		while(iter.hasNext()){
			this.varMap.add(new EnvironmentVariable(iter.next()));
		}
		
	}
	
	public EnvironmentVariable getThis(){	return thisVariable; }
	public void setThis(EnvironmentVariable var) {this.thisVariable = var;}
	
	public void addVariable(EnvironmentVariable vie){
		varMap.add(vie);
	}
	

	/*
	 * Given list of environment variables to be added, add them
	 */
	public void addVariables(List<EnvironmentVariable> var) {
		if(var == null){
			return;
		}
		Iterator<EnvironmentVariable> iter = var.iterator();
		
		while(iter.hasNext()){
			this.addVariable(iter.next());
		}
		
	}
	
	public EnvironmentVariable getVariable(String name){
		EnvironmentVariable _ret = null;
		_ret = searchInObject(thisVariable, name);
		if(_ret != null){
			return _ret;
		}
		
		int lastIndex = this.varMap.size()-1;
		
		for( ; lastIndex >= 0 ; --lastIndex){
			if(varMap.get(lastIndex).name.equals(name)){
				return varMap.get(lastIndex);
			}
		}
		System.out.println(" not found.. "+name);
		return null;
	}
	
	// add the recursive search feature
	private EnvironmentVariable searchInObject(EnvironmentVariable env, String name) {
		if(this.thisVariable == null){
			// there is no this.
			return null;
		}
		
		if(this.thisVariable.objectValue != null && !this.thisVariable.objectValue.isEmpty()){
			Iterator<EnvironmentVariable> iter = this.thisVariable.objectValue.iterator();
			while(iter.hasNext()){
				EnvironmentVariable var = iter.next();
				if(var.name.equals(name)){
					return var;
				}
			}
		}
		return null;
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		
		Iterator<EnvironmentVariable> iter = varMap.iterator();
		while(iter.hasNext()){
			sb.append(iter.next().toString()+"\n");
		}
		sb.append("this = "+thisVariable.toString());
		
		return sb.toString();
	}

}

