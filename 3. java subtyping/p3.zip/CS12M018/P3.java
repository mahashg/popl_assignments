

import syntaxtree.Node;
import visitor.GJNoArguDepthFirst;

public class P3 {

	public static void main(String[] args) throws Exception {
		
		/*java.util.Scanner read = new java.util.Scanner(System.in);
		new InterfaceParser(new FileInputStream(new File(read.nextLine().trim())));
		Node root = InterfaceParser.Goal();*/
		Node root = new InterfaceParser(System.in).Goal();
		root.accept(new GJNoArguDepthFirst());
	}

}
