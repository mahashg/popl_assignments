package store;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import syntaxtree.InterfaceDeclaration;
import syntaxtree.InterfaceMember;
import syntaxtree.Node;

public class DataStore {

	public static List<InterfaceMember> getInterface(String name){
		return memb.get(name);
	}
	
	public static boolean addInterface(InterfaceDeclaration intf){
		String name = intf.f1.f0.tokenImage;
		
		Iterator<Node> iter = intf.f2.f1.nodes.iterator();
		List<InterfaceMember> membList = new ArrayList<InterfaceMember>();
		
		while(iter.hasNext()){
			membList.add((InterfaceMember) iter.next());
		}
		
		//dummy code
		return (memb.put(name, membList) == null);
	}
	
	private final static Map<String, List<InterfaceMember>> memb = new HashMap<String, List<InterfaceMember>>();
	
	//private final static Map<String, InterfaceDeclaration> interfaceMapNode = new HashMap<String, InterfaceDeclaration>();
}
