package store;

import java.util.ArrayList;
import java.util.List;

import syntaxtree.BooleanType;
import syntaxtree.Identifier;
import syntaxtree.IntegerType;
import syntaxtree.InterfaceMember;
import syntaxtree.Node;
import syntaxtree.ResultType;
import syntaxtree.Type;
import syntaxtree.VoidType;

public class Utility {
	public static String readResultType(ResultType res){
		Node nd = res.f0.choice;

		if(nd instanceof VoidType){
			return readVoidType((VoidType)nd);
		}else {
			return readType((Type)nd);
		}
	}

	private static String readVoidType(VoidType nd) {

		return nd.f0.tokenImage;
	}

	public static String readType(Type nd) {
		Node tp = nd.f0.choice;

		if(tp instanceof BooleanType){
			return ((BooleanType) tp).f0.tokenImage;

		} else if(tp instanceof IntegerType){
			return ((IntegerType) tp).f0.tokenImage;

		} else if(tp instanceof Identifier){
			return ((Identifier) tp).f0.tokenImage;
		}

		return null;
	}

	public static List<InterfaceMember> createCloneOf(List<InterfaceMember> list){
		List<InterfaceMember> clonedList = new ArrayList<InterfaceMember>();
		if(list != null){
			for(InterfaceMember memb : list){
				clonedList.add(new InterfaceMember(memb.f0, memb.f1, memb.f3, memb.f4));
			}
		}
		return clonedList;
	}
}
