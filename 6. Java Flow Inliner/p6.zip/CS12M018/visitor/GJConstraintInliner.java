package visitor;

import java.util.ArrayList;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Vector;

import constraints.ConstraintCollection;

import syntaxtree.AllocationExpression;
import syntaxtree.AndExpression;
import syntaxtree.ArrayAllocationExpression;
import syntaxtree.ArrayAssignmentStatement;
import syntaxtree.ArrayLookup;
import syntaxtree.ArrayType;
import syntaxtree.AssignmentStatement;
import syntaxtree.Block;
import syntaxtree.BooleanType;
import syntaxtree.BracketExpression;
import syntaxtree.ClassDeclaration;
import syntaxtree.ClassExtendsDeclaration;
import syntaxtree.CompareExpression;
import syntaxtree.DotExpression;
import syntaxtree.Expression;
import syntaxtree.ExpressionList;
import syntaxtree.ExpressionRest;
import syntaxtree.FalseLiteral;
import syntaxtree.FormalParameter;
import syntaxtree.FormalParameterList;
import syntaxtree.FormalParameterRest;
import syntaxtree.Goal;
import syntaxtree.Identifier;
import syntaxtree.IfStatement;
import syntaxtree.IntegerLiteral;
import syntaxtree.IntegerType;
import syntaxtree.MainClass;
import syntaxtree.MessageSendStatement;
import syntaxtree.MethodDeclaration;
import syntaxtree.MinusExpression;
import syntaxtree.Node;
import syntaxtree.NodeChoice;
import syntaxtree.NodeList;
import syntaxtree.NodeListOptional;
import syntaxtree.NodeOptional;
import syntaxtree.NodeSequence;
import syntaxtree.NodeToken;
import syntaxtree.NotExpression;
import syntaxtree.PlusExpression;
import syntaxtree.PrimaryExpression;
import syntaxtree.PrintStatement;
import syntaxtree.Statement;
import syntaxtree.ThisExpression;
import syntaxtree.TimesExpression;
import syntaxtree.TrueLiteral;
import syntaxtree.Type;
import syntaxtree.TypeDeclaration;
import syntaxtree.VarDeclaration;
import syntaxtree.VarRef;
import syntaxtree.WhileStatement;

public class GJConstraintInliner implements GJNoArguVisitor<Node> {
	private String _class_name;
	private String _method_name;
	public Goal goal_node;
	public String _method_to_expand;
	
	
	private List<VarDeclaration> _new_method_vars = new ArrayList<VarDeclaration>();
	
	//
	// Auto class visitors--probably don't need to be overridden.
	//
	public Node visit(NodeList n) {
		NodeList _ret=new NodeList();

		for ( Enumeration<Node> e = n.elements(); e.hasMoreElements(); ) {
			_ret.addNode(e.nextElement().accept(this));
		}
		return _ret;
	}

	public Node visit(NodeListOptional n) {
		if ( n.present() ) {
			NodeListOptional _ret=new NodeListOptional();
			
			for ( Enumeration<Node> e = n.elements(); e.hasMoreElements(); ) {
				_ret.addNode(e.nextElement().accept(this));

			}
			return _ret;
		}
		else
			return new NodeListOptional();
	}

	public Node visit(NodeOptional n) {
		if ( n.present() )
			return new NodeOptional(n.node.accept(this));
		else
			return new NodeOptional();
	}

	public Node visit(NodeSequence n) {
		//TODO: to check this thing.
		NodeSequence _ret=new NodeSequence(1);
		// int _count=0;
		for ( Enumeration<Node> e = n.elements(); e.hasMoreElements(); ) {
			_ret.addNode(e.nextElement().accept(this));
			//   _count++;
		}
		return _ret;
	}

	public Node visit(NodeToken n) { return n; }

	//
	// User-generated visitor methods below
	//

	/**
	 * f0 -> MainClass()
	 * f1 -> ( TypeDeclaration() )*
	 * f2 -> <EOF>
	 */
	public Node visit(Goal n) {
		
		this.goal_node = n;
		n.f0.accept(this);
		NodeListOptional _nlo = (NodeListOptional) n.f1.accept(this);
		n.f2.accept(this);

		return new Goal(n.f0, _nlo);
	}

	/**
	 * f0 -> "class"
	 * f1 -> Identifier()
	 * f2 -> "{"
	 * f3 -> "public"
	 * f4 -> "static"
	 * f5 -> "void"
	 * f6 -> "main"
	 * f7 -> "("
	 * f8 -> "String"
	 * f9 -> "["
	 * f10 -> "]"
	 * f11 -> Identifier()
	 * f12 -> ")"
	 * f13 -> "{"
	 * f14 -> "new"
	 * f15 -> Identifier()
	 * f16 -> "("
	 * f17 -> ")"
	 * f18 -> "."
	 * f19 -> Identifier()
	 * f20 -> "("
	 * f21 -> ( ExpressionList() )?
	 * f22 -> ")"
	 * f23 -> ";"
	 * f24 -> "}"
	 * f25 -> "}"
	 */
	public Node visit(MainClass n) {
		Node _ret=null;
		n.f0.accept(this);
		n.f1.accept(this);
		n.f2.accept(this);
		n.f3.accept(this);
		n.f4.accept(this);
		n.f5.accept(this);
		n.f6.accept(this);
		n.f7.accept(this);
		n.f8.accept(this);
		n.f9.accept(this);
		n.f10.accept(this);
		n.f11.accept(this);
		n.f12.accept(this);
		n.f13.accept(this);
		n.f14.accept(this);
		n.f15.accept(this);
		n.f16.accept(this);
		n.f17.accept(this);
		n.f18.accept(this);
		n.f19.accept(this);
		n.f20.accept(this);
		n.f21.accept(this);
		n.f22.accept(this);
		n.f23.accept(this);
		n.f24.accept(this);
		n.f25.accept(this);
		return n;
	}

	/**
	 * f0 -> ClassDeclaration()
	 *       | ClassExtendsDeclaration()
	 */
	public Node visit(TypeDeclaration n) {
		return new TypeDeclaration(new NodeChoice(n.f0.accept(this)));
	}

	/**
	 * f0 -> "class"
	 * f1 -> Identifier()
	 * f2 -> "{"
	 * f3 -> ( VarDeclaration() )*
	 * f4 -> ( MethodDeclaration() )*
	 * f5 -> "}"
	 */
	public Node visit(ClassDeclaration n) {

		this._class_name = n.f1.accept(ToStringVisitor.visitor);
		
		n.f0.accept(this);
		n.f1.accept(this);
		n.f2.accept(this);
		n.f3.accept(this);
		NodeListOptional _nlo = (NodeListOptional) n.f4.accept(this);
		n.f5.accept(this);

		this._class_name = "";
		return new ClassDeclaration(n.f1, n.f3, _nlo);
	}

	/**
	 * f0 -> "class"
	 * f1 -> Identifier()
	 * f2 -> "extends"
	 * f3 -> Identifier()
	 * f4 -> "{"
	 * f5 -> ( VarDeclaration() )*
	 * f6 -> ( MethodDeclaration() )*
	 * f7 -> "}"
	 */
	public Node visit(ClassExtendsDeclaration n) {
		this._class_name = n.f1.accept(ToStringVisitor.visitor);
		
		
		n.f0.accept(this);
		n.f1.accept(this);
		n.f2.accept(this);
		n.f3.accept(this);
		n.f4.accept(this);
		n.f5.accept(this);
		NodeListOptional _nlo = (NodeListOptional) n.f6.accept(this);
		n.f7.accept(this);

		this._class_name = "";
		return new ClassExtendsDeclaration(n.f1, n.f3, n.f5, _nlo);
	}

	/**
	 * f0 -> Type()
	 * f1 -> Identifier()
	 * f2 -> ";"
	 */
	public Node visit(VarDeclaration n) {

		Node _ret=null;
		n.f0.accept(this);
		n.f1.accept(this);
		n.f2.accept(this);
		return n;
	}

	/**
	 * f0 -> "public"
	 * f1 -> "void"
	 * f2 -> Identifier()
	 * f3 -> "("
	 * f4 -> ( FormalParameterList() )?
	 * f5 -> ")"
	 * f6 -> "{"
	 * f7 -> ( VarDeclaration() )*
	 * f8 -> ( Statement() )*
	 * f9 -> "}"
	 */
	public Node visit(MethodDeclaration n) {
		this._method_name = n.f2.accept(ToStringVisitor.visitor);
		NodeListOptional _nlo = new NodeListOptional();
		MethodDeclaration _method_declare = null;
		_method_declare = new MethodDeclaration(n.f2, n.f4, n.f7, _nlo);
		      
		n.f0.accept(this);
		n.f1.accept(this);
		n.f2.accept(this);
		n.f3.accept(this);
		n.f4.accept(this);
		n.f5.accept(this);
		n.f6.accept(this);
		n.f7.accept(this);

		NodeListOptional _nlo1 = (NodeListOptional) n.f8.accept(this);
		n.f9.accept(this);

		if(_nlo1.present()){
			for(Node _nl : _nlo1.nodes ){
				_nlo.addNode(_nl);			
			}
		}
		
		doAnalysis(_method_declare);
		this._method_name = "";
		return _method_declare;
	}
	
	private void doAnalysis(MethodDeclaration _method_declare) {
		
		for(VarDeclaration _var : _new_method_vars){
			_method_declare.f7.addNode(_var);
			String _var_name = _var.f1.accept(ToStringVisitor.visitor);
			String _var_class = _var.f0.accept(ToStringVisitor.visitor);
			if(_var_class.equals("int ") || _var_class.equals("boolean ") || _var_class.equals("int[] ") ){
				continue;
			}
			// 1.
			ConstraintCollection._var_map.put(getFullVarName(_class_name, _method_name, _var_name), _var_class);
			
			// 2.
			Map<String, Boolean> _map = new HashMap<String, Boolean>();

			for(String _str : ConstraintCollection._cls_hier_map.get(_var_class)){
				_map.put(_str, false);
			}
			ConstraintCollection._var_type_map.put(getFullVarName(_class_name, _method_name, _var_name), _map);
		}
		_new_method_vars.clear();
		for(Node _nd : _method_declare.f8.nodes){
				Statement _stmt = (Statement) _nd;
				GJConstraintGeneratorVisitor _gen = new GJConstraintGeneratorVisitor();
				_gen.goal_node = this.goal_node;
				_gen._class_name = _class_name;
				_gen._method_name = _method_name;
				_stmt.accept(_gen);
		}
		
	}

	/**
	private void addToNodeList(NodeListOptional _nlo, Node _nd) {
		if(_nd instanceof NodeListOptional){
			if(((NodeListOptional) _nd).present()){
				for(Node _nd_inner : ((NodeListOptional) _nd).nodes){
					addToNodeList(_nlo, _nd_inner);
				}
			}
		}
		else if(_nd instanceof NodeList){
			for(Node _nd_inner : ((NodeList) _nd).nodes){
				addToNodeList(_nlo, _nd_inner);
			}
		}
		else if(_nd instanceof NodeOptional){
			if(((NodeOptional) _nd).present()){
				addToNodeList(_nlo, ((NodeOptional) _nd).node);
			}
		}
		else{
			_nlo.addNode(_nd);
		}
		
		
	}
*/
	/**
	 * f0 -> FormalParameter()
	 * f1 -> ( FormalParameterRest() )*
	 */
	public Node visit(FormalParameterList n) {
		Node _ret=null;
		n.f0.accept(this);
		n.f1.accept(this);
		return n;
	}

	/**
	 * f0 -> Type()
	 * f1 -> Identifier()
	 */
	public Node visit(FormalParameter n) {
		Node _ret=null;

		n.f0.accept(this);
		n.f1.accept(this);
		return n;
	}

	/**
	 * f0 -> ","
	 * f1 -> FormalParameter()
	 */
	public Node visit(FormalParameterRest n) {
		Node _ret=null;
		n.f0.accept(this);
		n.f1.accept(this);
		return n;
	}

	/**
	 * f0 -> ArrayType()
	 *       | BooleanType()
	 *       | IntegerType()
	 *       | Identifier()
	 */
	public Node visit(Type n) {
		Node _ret=null;
		n.f0.accept(this);
		return _ret;
	}

	/**
	 * f0 -> "int"
	 * f1 -> "["
	 * f2 -> "]"
	 */
	public Node visit(ArrayType n) {
		Node _ret=null;
		n.f0.accept(this);
		n.f1.accept(this);
		n.f2.accept(this);
		return _ret;
	}

	/**
	 * f0 -> "boolean"
	 */
	public Node visit(BooleanType n) {
		Node _ret=null;
		n.f0.accept(this);
		return _ret;
	}

	/**
	 * f0 -> "int"
	 */
	public Node visit(IntegerType n) {
		Node _ret=null;
		n.f0.accept(this);
		return _ret;
	}

	/**
	 * f0 -> Block()
	 *       | AssignmentStatement()
	 *       | ArrayAssignmentStatement()
	 *       | IfStatement()
	 *       | WhileStatement()
	 *       | PrintStatement()
	 *       | MessageSendStatement()
	 */
	public Node visit(Statement n) {
		Node _nd = n.f0.accept(this);
		
		if(_nd instanceof NodeListOptional){
			
			return new Statement(new NodeChoice(new Block((NodeListOptional) _nd)));
			
		}else if(_nd instanceof NodeList){
			NodeListOptional _nlo = new NodeListOptional();
			_nlo.nodes = ((NodeList) _nd).nodes;
			return new Statement(new NodeChoice(new Block(_nlo)));
			
		}
				
		return new Statement(new NodeChoice(_nd));
	}

	/**
	 * f0 -> "{"
	 * f1 -> ( Statement() )*
	 * f2 -> "}"
	 */
	public Node visit(Block n) {
		
		n.f0.accept(this);
		NodeListOptional _nlo = (NodeListOptional) n.f1.accept(this);
		n.f2.accept(this);
		
		return new Block(_nlo);
	}

	/**
	 * f0 -> VarRef()
	 * f1 -> "="
	 * f2 -> Expression()
	 * f3 -> ";"
	 */
	public Node visit(AssignmentStatement n) {
		Node _ret=null;
		n.f0.accept(this);
		n.f1.accept(this);
		n.f2.accept(this);
		n.f3.accept(this);
		return n;
	}

	/**
	 * f0 -> Identifier()
	 * f1 -> "["
	 * f2 -> Expression()
	 * f3 -> "]"
	 * f4 -> "="
	 * f5 -> Expression()
	 * f6 -> ";"
	 */
	public Node visit(ArrayAssignmentStatement n) {
		Node _ret=null;
		n.f0.accept(this);
		n.f1.accept(this);
		n.f2.accept(this);
		n.f3.accept(this);
		n.f4.accept(this);
		n.f5.accept(this);
		n.f6.accept(this);
		return n;
	}

	/**
	 * f0 -> "if"
	 * f1 -> "("
	 * f2 -> Expression()
	 * f3 -> ")"
	 * f4 -> Statement()
	 * f5 -> "else"
	 * f6 -> Statement()
	 */
	public Node visit(IfStatement n) {
		
		NodeListOptional _nlo1, _nlo2;
		Node n0 = n.f0.accept(this);
		Node n1 = n.f1.accept(this);
		Node n2 = n.f2.accept(this);
		Node n3 = n.f3.accept(this);
		Node n4 = n.f4.accept(this);
		if(n4 instanceof NodeListOptional){
			_nlo1 = (NodeListOptional)n4;	
		}else {
			_nlo1 = new NodeListOptional(n4);
		}
		
		Node n5 = n.f5.accept(this);
		Node n6 = n.f6.accept(this);
		if(n6 instanceof NodeListOptional){
			_nlo2 = (NodeListOptional) n6;
		}else {
			_nlo2 = new NodeListOptional(n6);
		}
		
		
		return new IfStatement(n.f2, new Statement(new NodeChoice(new Block(_nlo1))), new Statement(new NodeChoice(new Block(_nlo2))));
	}

	/**
	 * f0 -> "while"
	 * f1 -> "("
	 * f2 -> Expression()
	 * f3 -> ")"
	 * f4 -> Statement()
	 */
	public Node visit(WhileStatement n) {
		NodeListOptional _nlo;
		Node _ret=null;
		Node n0 = n.f0.accept(this);
		Node n1 = n.f1.accept(this);
		Node n2 = n.f2.accept(this);
		Node n3 = n.f3.accept(this);
		Node n4 = n.f4.accept(this);
		if(n4 instanceof NodeListOptional){
			_nlo = (NodeListOptional) n4;
		}else {
			_nlo = new NodeListOptional(n4);
		}
		//TODO: make n4 a block statement
		return new WhileStatement(n.f2, new Statement(new NodeChoice(new Block(_nlo))));
	}

	/**
	 * f0 -> "System.out.println"
	 * f1 -> "("
	 * f2 -> Expression()
	 * f3 -> ")"
	 * f4 -> ";"
	 */
	public Node visit(PrintStatement n) {
		Node _ret=null;
		n.f0.accept(this);
		n.f1.accept(this);
		n.f2.accept(this);
		n.f3.accept(this);
		n.f4.accept(this);
		
		return n;
	}

	/**
	 * f0 -> Identifier()
	 * f1 -> "."
	 * f2 -> Identifier()
	 * f3 -> "("
	 * f4 -> ( ExpressionList() )?
	 * f5 -> ")"
	 * f6 -> ";"
	 */
	public Node visit(MessageSendStatement n) {
		
		String _var_name = getFullVarName(_class_name, _method_name, n.f0.accept(ToStringVisitor.visitor));		
		String _var_new_class = getInlinedClass(_var_name);
		String _method_name = n.f2.accept(ToStringVisitor.visitor);
		NodeListOptional _opt = new NodeListOptional();
		
		if(!(_var_new_class+"."+_method_name).equals(_method_to_expand)){
			return n;
		}
		
		if(_var_new_class != null){
		
			if(_method_name.equals(this._method_name) && _var_new_class.equals(_class_name)){
				return n;
			}else {
		
				MethodDeclaration _method = getMethodOfClass(_var_new_class, _method_name);

				// 1. method parameters
				List<Expression> expr_list = getListOfExpression(n.f4.node);
				List<FormalParameter> formal_list = getListOfFormalParameters(_method.f4.node);				
				List<FormalParameter> formal_list_new = new ArrayList<FormalParameter>();
				List<VarDeclaration> _newVar_list = new ArrayList<VarDeclaration>();
				List<AssignmentStatement> _assign_list = new ArrayList<AssignmentStatement>();
				List<Node> _stmt_list = new ArrayList<Node>();

				// NEW FORMAL PARAM LIST
				for(int i=0 ; i<formal_list.size() ; ++i){
					FormalParameter _old = formal_list.get(i);
					FormalParameter _new_param = new FormalParameter(_old.f0, new Identifier(new NodeToken(_old.f1.f0.tokenImage+"_"+System.nanoTime())));
					formal_list_new.add(_new_param);
				}

				for(int i=0 ; i<formal_list_new.size() ; ++i){
					FormalParameter _param = formal_list_new.get(i);					
					VarDeclaration _var = new VarDeclaration(_param.f0, _param.f1);
					_newVar_list.add(_var);
				}

				// LIST OF ALL ASSIGNMENTS TO BE ADDED
				for(int i=0 ; i<formal_list_new.size() ; ++i){
					FormalParameter _formal = formal_list_new.get(i);
					Expression _expr = expr_list.get(i);
					AssignmentStatement _assign = new AssignmentStatement(new VarRef(new NodeChoice(_formal.f1)), _expr);
					_assign_list.add(_assign);
				}

				// 2. HANDLE MEMBER VARIABLES OF THE GIVEN CLASS
				// replace the call via alternate one
				NodeListOptional _memberOptional = readClassMembers(_var_new_class);
				if(_memberOptional.present()){
					for(Node _nd : _memberOptional.nodes){
						VarDeclaration _var = (VarDeclaration) _nd;
						formal_list_new.add(new FormalParameter(_var.f0, new Identifier(new NodeToken(n.f0.accept(ToStringVisitor.visitor)+"."+_var.f1.accept(ToStringVisitor.visitor)))));
						formal_list.add(new FormalParameter(_var.f0, _var.f1));
					}
				}

				// 3. HANDLE LOCAL VARIABLES OF ANOTHER METHOD
				//Variable to declare
				// Declare it here...
				if(_method.f7.present()){
					for(Node _nd : _method.f7.nodes){
						VarDeclaration _var = (VarDeclaration) _nd;

						//TODO: handle extra space
						VarDeclaration _var_new = new VarDeclaration(_var.f0, new Identifier(new NodeToken(_var.f1.f0.tokenImage+"_"+System.nanoTime())));
						_newVar_list.add(_var_new);

						expr_list.add(new Expression(new NodeChoice(new PrimaryExpression(new NodeChoice(new VarRef(new NodeChoice(_var_new.f1)))))));
						formal_list.add(new FormalParameter(_var.f0, _var.f1));
						formal_list_new.add(new FormalParameter(_var_new.f0, _var_new.f1));
					}
				}

				// 4. THIS EXPRESSION HANDLE
				formal_list_new.add(new FormalParameter(new Type(new NodeChoice(new Identifier(new NodeToken(_var_new_class)))), n.f0));
				formal_list.add(new FormalParameter(new Type(new NodeChoice(new Identifier(new NodeToken(_var_new_class)))), new Identifier(new NodeToken("this"))));

				if( _method.f8.present()){

					GJConstraintReplacerVisitor replacer = new GJConstraintReplacerVisitor();
					replacer.expr_list = expr_list;
					replacer.formal_list = formal_list;
					replacer.formal_list_new = formal_list_new;

					replacer._class_name = _var_new_class;
					replacer._method_name = _method_name;

					for(Node _nd : _method.f8.nodes){
						Statement _stmt = (Statement) _nd;
						Node _nd_stmt = _stmt.accept(replacer);
						_stmt_list.add(_nd_stmt);
					}
					
					
					for(VarDeclaration _var : _newVar_list){
						_new_method_vars.add(_var);
					}
					
					for(AssignmentStatement _assign : _assign_list){
						_opt.addNode(_assign);
					}
					
					for(Node _stmt : _stmt_list){
						_opt.addNode(_stmt);
					}
				}

			}
		}else {
		
		}
		n.f0.accept(this);
		n.f1.accept(this);
		n.f2.accept(this);
		n.f3.accept(this);
		n.f4.accept(this);
		n.f5.accept(this);
		n.f6.accept(this);

		return _opt;
	}

	/**
	 * f0 -> AndExpression()
	 *       | CompareExpression()
	 *       | PlusExpression()
	 *       | MinusExpression()
	 *       | TimesExpression()
	 *       | ArrayLookup()
	 *       | PrimaryExpression()
	 */
	public Node visit(Expression n) {		
		return new Expression(new NodeChoice(n.f0.accept(this)));
	}

	/**
	 * f0 -> PrimaryExpression()
	 * f1 -> "&"
	 * f2 -> PrimaryExpression()
	 */
	public Node visit(AndExpression n) {
		Node _ret=null;
		n.f0.accept(this);
		n.f1.accept(this);
		n.f2.accept(this);
		return n;
	}

	/**
	 * f0 -> PrimaryExpression()
	 * f1 -> "<"
	 * f2 -> PrimaryExpression()
	 */
	public Node visit(CompareExpression n) {
		Node _ret=null;
		n.f0.accept(this);
		n.f1.accept(this);
		n.f2.accept(this);
		return n;
	}

	/**
	 * f0 -> PrimaryExpression()
	 * f1 -> "+"
	 * f2 -> PrimaryExpression()
	 */
	public Node visit(PlusExpression n) {
		Node _ret=null;
		n.f0.accept(this);
		n.f1.accept(this);
		n.f2.accept(this);
		return n;
	}

	/**
	 * f0 -> PrimaryExpression()
	 * f1 -> "-"
	 * f2 -> PrimaryExpression()
	 */
	public Node visit(MinusExpression n) {
		Node _ret=null;
		n.f0.accept(this);
		n.f1.accept(this);
		n.f2.accept(this);
		return n;
	}

	/**
	 * f0 -> PrimaryExpression()
	 * f1 -> "*"
	 * f2 -> PrimaryExpression()
	 */
	public Node visit(TimesExpression n) {
		Node _ret=null;
		n.f0.accept(this);
		n.f1.accept(this);
		n.f2.accept(this);
		return n;
	}

	/**
	 * f0 -> PrimaryExpression()
	 * f1 -> "["
	 * f2 -> PrimaryExpression()
	 * f3 -> "]"
	 */
	public Node visit(ArrayLookup n) {
		Node _ret=null;
		n.f0.accept(this);
		n.f1.accept(this);
		n.f2.accept(this);
		n.f3.accept(this);
		return n;
	}

	/**
	 * f0 -> Expression()
	 * f1 -> ( ExpressionRest() )*
	 */
	public Node visit(ExpressionList n) {
		Node _ret=null;
		n.f0.accept(this);
		n.f1.accept(this);
		return n;
	}

	/**
	 * f0 -> ","
	 * f1 -> Expression()
	 */
	public Node visit(ExpressionRest n) {
		Node _ret=null;
		n.f0.accept(this);
		n.f1.accept(this);
		return n;
	}

	/**
	 * f0 -> IntegerLiteral()
	 *       | TrueLiteral()
	 *       | FalseLiteral()
	 *       | VarRef()
	 *       | ThisExpression()
	 *       | ArrayAllocationExpression()
	 *       | AllocationExpression()
	 *       | NotExpression()
	 *       | BracketExpression()
	 */
	public Node visit(PrimaryExpression n) {
		
		return new PrimaryExpression(new NodeChoice(n.f0.accept(this)));
	}

	/**
	 * f0 -> <INTEGER_LITERAL>
	 */
	public Node visit(IntegerLiteral n) {
		Node _ret=null;
		n.f0.accept(this);
		return n;
	}

	/**
	 * f0 -> "true"
	 */
	public Node visit(TrueLiteral n) {
		Node _ret=null;
		n.f0.accept(this);
		return n;
	}

	/**
	 * f0 -> "false"
	 */
	public Node visit(FalseLiteral n) {
		Node _ret=null;
		n.f0.accept(this);
		return n;
	}

	/**
	 * f0 -> <IDENTIFIER>
	 */
	public Node visit(Identifier n) {
		Node _ret=null;
		n.f0.accept(this);
		return n;
	}

	/**
	 * f0 -> "this"
	 */
	public Node visit(ThisExpression n) {
		Node _ret=null;
		n.f0.accept(this);
		return n;
	}

	/**
	 * f0 -> "new"
	 * f1 -> "int"
	 * f2 -> "["
	 * f3 -> Expression()
	 * f4 -> "]"
	 */
	public Node visit(ArrayAllocationExpression n) {
		Node _ret=null;
		n.f0.accept(this);
		n.f1.accept(this);
		n.f2.accept(this);
		n.f3.accept(this);
		n.f4.accept(this);
		return n;
	}

	/**
	 * f0 -> "new"
	 * f1 -> Identifier()
	 * f2 -> "("
	 * f3 -> ")"
	 */
	public Node visit(AllocationExpression n) {

		Node _ret=null;
		n.f0.accept(this);
		n.f1.accept(this);
		n.f2.accept(this);
		n.f3.accept(this);
		return n;
	}

	/**
	 * f0 -> "!"
	 * f1 -> Expression()
	 */
	public Node visit(NotExpression n) {
		Node _ret=null;
		n.f0.accept(this);
		n.f1.accept(this);
		return n;
	}

	/**
	 * f0 -> "("
	 * f1 -> Expression()
	 * f2 -> ")"
	 */
	public Node visit(BracketExpression n) {
		Node _ret=null;
		n.f0.accept(this);
		n.f1.accept(this);
		n.f2.accept(this);
		return n;
	}

	/**
	 * f0 -> DotExpression()
	 *       | Identifier()
	 */
	public Node visit(VarRef n) {
		Node _ret=null;
		
		return new VarRef(new NodeChoice(n.f0.accept(this)));
	}

	/**
	 * f0 -> Identifier()
	 * f1 -> "."
	 * f2 -> Identifier()
	 */
	public Node visit(DotExpression n) {
		Node _ret=null;
		n.f0.accept(this);
		n.f1.accept(this);
		n.f2.accept(this);
		return n;
	}

	/**
	 * ---------------------------------------------------------------------------
	 * 					HELPER METHODS
	 * ---------------------------------------------------------------------------
	 */
	public String getFullVarName(String _cls, String _met, String _var){

		if(ConstraintCollection._var_map.containsKey(_cls+"."+_met+"."+_var)){
			return _cls+"."+_met+"."+_var;
		}else if(ConstraintCollection._var_map.containsKey(_cls+".."+_var)){
			return _cls+".."+_var;
		}
		return _cls+"."+_met+"."+_var;
	}

	private MethodDeclaration getMethodOfClass(String _class, String _method_name) {
		for( Node nd :this.goal_node.f1.nodes){
			Node _nd_cls = ((TypeDeclaration) nd).f0.choice;

			Vector<Node> _node_list = new Vector<Node>();
			if(_nd_cls instanceof ClassDeclaration){
				ClassDeclaration _clsdecl = (ClassDeclaration) _nd_cls;

				if(_clsdecl.f1.accept(ToStringVisitor.visitor).equals(_class)){
					_node_list = _clsdecl.f4.nodes;
				}
			}else if(_nd_cls instanceof ClassExtendsDeclaration){
				ClassExtendsDeclaration _clsextn = (ClassExtendsDeclaration) _nd_cls;

				if(_clsextn.f1.accept(ToStringVisitor.visitor).equals(_class)){
					_node_list = _clsextn.f6.nodes;
				}
			}

			for(Node _nd_method : _node_list){
				MethodDeclaration _method = (MethodDeclaration) _nd_method;

				if(_method.f2.accept(ToStringVisitor.visitor).equals(_method_name)){
					return _method;
				}
			}
		}
		return null;
	}
	
	private NodeListOptional readClassMembers(String _class_name) {
		if(this.goal_node.f1.present()){

			for(Node _nd : this.goal_node.f1.nodes){
				_nd = ((TypeDeclaration)_nd).f0.choice;

				if(_nd instanceof ClassDeclaration){
					if(((ClassDeclaration) _nd).f1.accept(ToStringVisitor.visitor).equals(_class_name)){
						return ((ClassDeclaration) _nd).f3;
					}
				}else if(_nd instanceof ClassExtendsDeclaration){
					if(((ClassExtendsDeclaration) _nd).f1.accept(ToStringVisitor.visitor).equals(_class_name)){
						return ((ClassExtendsDeclaration) _nd).f5;
					}
				}
			}
		}
		return null;
	}

	private List<FormalParameter> getListOfFormalParameters(Node nd){
		List<FormalParameter> _list = new ArrayList<FormalParameter>();
		if(nd != null){
			FormalParameterList _formal_list = (FormalParameterList) nd;
			_list.add(_formal_list.f0);
			if(_formal_list.f1.present()){
				for(Node _nd : _formal_list.f1.nodes){
					FormalParameterRest f_rest = (FormalParameterRest) _nd;
					_list.add(f_rest.f1);
				}
			}
		}
		return _list;
	}

	private List<Expression> getListOfExpression(Node nd){
		List<Expression> _list = new ArrayList<Expression>();
		if(nd != null){
			ExpressionList expr_list = (ExpressionList) nd;
			_list.add(expr_list.f0);
			if(expr_list.f1.present()){
				for(Node _nd : expr_list.f1.nodes){
					ExpressionRest _rest = (ExpressionRest) _nd;
					_list.add(_rest.f1);

				}
			}
		}
		return _list;
	}
	private String getInlinedClass(String _var_name) {
		Map<String, Boolean> _map = ConstraintCollection._var_type_map.get(_var_name);

		int count = 0 ;
		String _class = null;

		for(String _str : _map.keySet()){
			if(_map.get(_str)){
				_class = _str;
				++count;				
			}
		}

		if(count == 1){ return _class;}
		else return null;
	}



}
