package visitor;

import java.util.ArrayList;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Vector;

import syntaxtree.AllocationExpression;
import syntaxtree.AndExpression;
import syntaxtree.ArrayAllocationExpression;
import syntaxtree.ArrayAssignmentStatement;
import syntaxtree.ArrayLookup;
import syntaxtree.ArrayType;
import syntaxtree.AssignmentStatement;
import syntaxtree.Block;
import syntaxtree.BooleanType;
import syntaxtree.BracketExpression;
import syntaxtree.ClassDeclaration;
import syntaxtree.ClassExtendsDeclaration;
import syntaxtree.CompareExpression;
import syntaxtree.DotExpression;
import syntaxtree.Expression;
import syntaxtree.ExpressionList;
import syntaxtree.ExpressionRest;
import syntaxtree.FalseLiteral;
import syntaxtree.FormalParameter;
import syntaxtree.FormalParameterList;
import syntaxtree.FormalParameterRest;
import syntaxtree.Goal;
import syntaxtree.Identifier;
import syntaxtree.IfStatement;
import syntaxtree.IntegerLiteral;
import syntaxtree.IntegerType;
import syntaxtree.MainClass;
import syntaxtree.MessageSendStatement;
import syntaxtree.MethodDeclaration;
import syntaxtree.MinusExpression;
import syntaxtree.Node;
import syntaxtree.NodeList;
import syntaxtree.NodeListOptional;
import syntaxtree.NodeOptional;
import syntaxtree.NodeSequence;
import syntaxtree.NodeToken;
import syntaxtree.NotExpression;
import syntaxtree.PlusExpression;
import syntaxtree.PrimaryExpression;
import syntaxtree.PrintStatement;
import syntaxtree.Statement;
import syntaxtree.ThisExpression;
import syntaxtree.TimesExpression;
import syntaxtree.TrueLiteral;
import syntaxtree.Type;
import syntaxtree.TypeDeclaration;
import syntaxtree.VarDeclaration;
import syntaxtree.VarRef;
import syntaxtree.WhileStatement;
import constraints.ConstraintCollection;

public class GJConstraintSubstitution<R> implements GJNoArguVisitor<R> {
	private String _class_name;
	private String _method_name;
	public Goal goal_node;
	//
	// Auto class visitors--probably don't need to be overridden.
	//
	public R visit(NodeList n) {
		R _ret=null;
		//  int _count=0;
		for ( Enumeration<Node> e = n.elements(); e.hasMoreElements(); ) {
			e.nextElement().accept(this);
			//   _count++;
		}
		return _ret;
	}

	public R visit(NodeListOptional n) {
		if ( n.present() ) {
			R _ret=null;
			// int _count=0;
			for ( Enumeration<Node> e = n.elements(); e.hasMoreElements(); ) {
				e.nextElement().accept(this);
				//  _count++;
			}
			return _ret;
		}
		else
			return null;
	}

	public R visit(NodeOptional n) {
		if ( n.present() )
			return n.node.accept(this);
		else
			return null;
	}

	public R visit(NodeSequence n) {
		R _ret=null;
		// int _count=0;
		for ( Enumeration<Node> e = n.elements(); e.hasMoreElements(); ) {
			e.nextElement().accept(this);
			//   _count++;
		}
		return _ret;
	}

	public R visit(NodeToken n) { return null; }

	//
	// User-generated visitor methods below
	//

	/**
	 * f0 -> MainClass()
	 * f1 -> ( TypeDeclaration() )*
	 * f2 -> <EOF>
	 */
	public R visit(Goal n) {

		R _ret=null;
		this.goal_node = n;

		n.f0.accept(this);
		n.f1.accept(this);
		n.f2.accept(this);


		
		return _ret;
	}

	/**
	 * f0 -> "class"
	 * f1 -> Identifier()
	 * f2 -> "{"
	 * f3 -> "public"
	 * f4 -> "static"
	 * f5 -> "void"
	 * f6 -> "main"
	 * f7 -> "("
	 * f8 -> "String"
	 * f9 -> "["
	 * f10 -> "]"
	 * f11 -> Identifier()
	 * f12 -> ")"
	 * f13 -> "{"
	 * f14 -> "new"
	 * f15 -> Identifier()
	 * f16 -> "("
	 * f17 -> ")"
	 * f18 -> "."
	 * f19 -> Identifier()
	 * f20 -> "("
	 * f21 -> ( ExpressionList() )?
	 * f22 -> ")"
	 * f23 -> ";"
	 * f24 -> "}"
	 * f25 -> "}"
	 */
	public R visit(MainClass n) {
		R _ret=null;
		n.f0.accept(this);
		n.f1.accept(this);
		n.f2.accept(this);
		n.f3.accept(this);
		n.f4.accept(this);
		n.f5.accept(this);
		n.f6.accept(this);
		n.f7.accept(this);
		n.f8.accept(this);
		n.f9.accept(this);
		n.f10.accept(this);
		n.f11.accept(this);
		n.f12.accept(this);
		n.f13.accept(this);
		n.f14.accept(this);
		n.f15.accept(this);
		n.f16.accept(this);
		n.f17.accept(this);
		n.f18.accept(this);
		n.f19.accept(this);
		n.f20.accept(this);
		n.f21.accept(this);
		n.f22.accept(this);
		n.f23.accept(this);
		n.f24.accept(this);
		n.f25.accept(this);
		return _ret;
	}

	/**
	 * f0 -> ClassDeclaration()
	 *       | ClassExtendsDeclaration()
	 */
	public R visit(TypeDeclaration n) {
		R _ret=null;
		n.f0.accept(this);
		return _ret;
	}

	/**
	 * f0 -> "class"
	 * f1 -> Identifier()
	 * f2 -> "{"
	 * f3 -> ( VarDeclaration() )*
	 * f4 -> ( MethodDeclaration() )*
	 * f5 -> "}"
	 */
	public R visit(ClassDeclaration n) {

		this._class_name = n.f1.accept(ToStringVisitor.visitor);
		this._method_name = "";
		R _ret=null;
		n.f0.accept(this);
		n.f1.accept(this);
		n.f2.accept(this);
		n.f3.accept(this);
		n.f4.accept(this);
		n.f5.accept(this);
		this._class_name = "";
		return _ret;
	}

	/**
	 * f0 -> "class"
	 * f1 -> Identifier()
	 * f2 -> "extends"
	 * f3 -> Identifier()
	 * f4 -> "{"
	 * f5 -> ( VarDeclaration() )*
	 * f6 -> ( MethodDeclaration() )*
	 * f7 -> "}"
	 */
	public R visit(ClassExtendsDeclaration n) {
		this._class_name = n.f1.accept(ToStringVisitor.visitor);
		R _ret=null;
		n.f0.accept(this);
		n.f1.accept(this);
		n.f2.accept(this);
		n.f3.accept(this);
		n.f4.accept(this);
		n.f5.accept(this);
		n.f6.accept(this);
		n.f7.accept(this);
		this._class_name = "";
		return _ret;
	}

	/**
	 * f0 -> Type()
	 * f1 -> Identifier()
	 * f2 -> ";"
	 */
	public R visit(VarDeclaration n) {

		R _ret=null;
		n.f0.accept(this);
		n.f1.accept(this);
		n.f2.accept(this);
		return _ret;
	}

	/**
	 * f0 -> "public"
	 * f1 -> "void"
	 * f2 -> Identifier()
	 * f3 -> "("
	 * f4 -> ( FormalParameterList() )?
	 * f5 -> ")"
	 * f6 -> "{"
	 * f7 -> ( VarDeclaration() )*
	 * f8 -> ( Statement() )*
	 * f9 -> "}"
	 */
	public R visit(MethodDeclaration n) {
		this._method_name = n.f2.accept(ToStringVisitor.visitor);
		R _ret=null;      
		n.f0.accept(this);
		n.f1.accept(this);
		n.f2.accept(this);
		n.f3.accept(this);
		n.f4.accept(this);
		n.f5.accept(this);
		n.f6.accept(this);
		n.f7.accept(this);
		n.f8.accept(this);
		n.f9.accept(this);

		this._method_name = "";
		return _ret;
	}

	/**
	 * f0 -> FormalParameter()
	 * f1 -> ( FormalParameterRest() )*
	 */
	public R visit(FormalParameterList n) {
		R _ret=null;
		n.f0.accept(this);
		n.f1.accept(this);
		return _ret;
	}

	/**
	 * f0 -> Type()
	 * f1 -> Identifier()
	 */
	public R visit(FormalParameter n) {
		R _ret=null;

		n.f0.accept(this);
		n.f1.accept(this);
		return _ret;
	}

	/**
	 * f0 -> ","
	 * f1 -> FormalParameter()
	 */
	public R visit(FormalParameterRest n) {
		R _ret=null;
		n.f0.accept(this);
		n.f1.accept(this);
		return _ret;
	}

	/**
	 * f0 -> ArrayType()
	 *       | BooleanType()
	 *       | IntegerType()
	 *       | Identifier()
	 */
	public R visit(Type n) {
		R _ret=null;
		n.f0.accept(this);
		return _ret;
	}

	/**
	 * f0 -> "int"
	 * f1 -> "["
	 * f2 -> "]"
	 */
	public R visit(ArrayType n) {
		R _ret=null;
		n.f0.accept(this);
		n.f1.accept(this);
		n.f2.accept(this);
		return _ret;
	}

	/**
	 * f0 -> "boolean"
	 */
	public R visit(BooleanType n) {
		R _ret=null;
		n.f0.accept(this);
		return _ret;
	}

	/**
	 * f0 -> "int"
	 */
	public R visit(IntegerType n) {
		R _ret=null;
		n.f0.accept(this);
		return _ret;
	}

	/**
	 * f0 -> Block()
	 *       | AssignmentStatement()
	 *       | ArrayAssignmentStatement()
	 *       | IfStatement()
	 *       | WhileStatement()
	 *       | PrintStatement()
	 *       | MessageSendStatement()
	 */
	public R visit(Statement n) {
		R _ret=null;
		n.f0.accept(this);
		return _ret;
	}

	/**
	 * f0 -> "{"
	 * f1 -> ( Statement() )*
	 * f2 -> "}"
	 */
	public R visit(Block n) {
		R _ret=null;
		n.f0.accept(this);
		n.f1.accept(this);
		n.f2.accept(this);
		return _ret;
	}

	/**
	 * f0 -> VarRef()
	 * f1 -> "="
	 * f2 -> Expression()
	 * f3 -> ";"
	 */
	public R visit(AssignmentStatement n) {
		R _ret=null;
		n.f0.accept(this);
		n.f1.accept(this);
		n.f2.accept(this);
		n.f3.accept(this);
		return _ret;
	}

	/**
	 * f0 -> Identifier()
	 * f1 -> "["
	 * f2 -> Expression()
	 * f3 -> "]"
	 * f4 -> "="
	 * f5 -> Expression()
	 * f6 -> ";"
	 */
	public R visit(ArrayAssignmentStatement n) {
		R _ret=null;
		n.f0.accept(this);
		n.f1.accept(this);
		n.f2.accept(this);
		n.f3.accept(this);
		n.f4.accept(this);
		n.f5.accept(this);
		n.f6.accept(this);
		return _ret;
	}

	/**
	 * f0 -> "if"
	 * f1 -> "("
	 * f2 -> Expression()
	 * f3 -> ")"
	 * f4 -> Statement()
	 * f5 -> "else"
	 * f6 -> Statement()
	 */
	public R visit(IfStatement n) {
		R _ret=null;
		n.f0.accept(this);
		n.f1.accept(this);
		n.f2.accept(this);
		n.f3.accept(this);
		n.f4.accept(this);
		n.f5.accept(this);
		n.f6.accept(this);
		return _ret;
	}

	/**
	 * f0 -> "while"
	 * f1 -> "("
	 * f2 -> Expression()
	 * f3 -> ")"
	 * f4 -> Statement()
	 */
	public R visit(WhileStatement n) {
		R _ret=null;
		n.f0.accept(this);
		n.f1.accept(this);
		n.f2.accept(this);
		n.f3.accept(this);
		n.f4.accept(this);
		return _ret;
	}

	/**
	 * f0 -> "System.out.println"
	 * f1 -> "("
	 * f2 -> Expression()
	 * f3 -> ")"
	 * f4 -> ";"
	 */
	public R visit(PrintStatement n) {
		R _ret=null;
		n.f0.accept(this);
		n.f1.accept(this);
		n.f2.accept(this);
		n.f3.accept(this);
		n.f4.accept(this);
		return _ret;
	}

	/**
	 * f0 -> Identifier()
	 * f1 -> "."
	 * f2 -> Identifier()
	 * f3 -> "("
	 * f4 -> ( ExpressionList() )?
	 * f5 -> ")"
	 * f6 -> ";"
	 */
	public R visit(MessageSendStatement n) {
		R _ret=null;

		String _var_name = n.f0.accept(ToStringVisitor.visitor);

		Map<String, Boolean> _map = new HashMap<String, Boolean>();
		for(String _str : ConstraintCollection._cls_hier_map.get(getVarType(_var_name))){
			_map.put(_str, false);
		}
		ConstraintCollection._var_type_map.put(getFullVarName(this._class_name, this._method_name, _var_name), _map);

		
		n.f0.accept(this);
		n.f1.accept(this);
		n.f2.accept(this);
		n.f3.accept(this);
		n.f4.accept(this);
		n.f5.accept(this);
		n.f6.accept(this);

		return _ret;
	}


	private MethodDeclaration getMethodOfClass(String _class, String _method_name) {
		//	System.out.println(_class+", "+_method_name);

		for( Node nd :this.goal_node.f1.nodes){
			Node _nd_cls = ((TypeDeclaration) nd).f0.choice;

			Vector<Node> _node_list = new Vector<Node>();
			if(_nd_cls instanceof ClassDeclaration){
				ClassDeclaration _clsdecl = (ClassDeclaration) _nd_cls;

				if(_clsdecl.f1.accept(ToStringVisitor.visitor).equals(_class)){
					_node_list = _clsdecl.f4.nodes;
				}
			}else if(_nd_cls instanceof ClassExtendsDeclaration){
				ClassExtendsDeclaration _clsextn = (ClassExtendsDeclaration) _nd_cls;

				if(_clsextn.f1.accept(ToStringVisitor.visitor).equals(_class)){
					_node_list = _clsextn.f6.nodes;
				}
			}

			for(Node _nd_method : _node_list){
				MethodDeclaration _method = (MethodDeclaration) _nd_method;

				if(_method.f2.accept(ToStringVisitor.visitor).equals(_method_name)){
					return _method;
				}
			}
		}
		//System.out.println("return null");
		return null;
	}

	/**
	 * f0 -> AndExpression()
	 *       | CompareExpression()
	 *       | PlusExpression()
	 *       | MinusExpression()
	 *       | TimesExpression()
	 *       | ArrayLookup()
	 *       | PrimaryExpression()
	 */
	public R visit(Expression n) {
		R _ret=null;
		n.f0.accept(this);
		return _ret;
	}

	/**
	 * f0 -> PrimaryExpression()
	 * f1 -> "&"
	 * f2 -> PrimaryExpression()
	 */
	public R visit(AndExpression n) {
		R _ret=null;
		n.f0.accept(this);
		n.f1.accept(this);
		n.f2.accept(this);
		return _ret;
	}

	/**
	 * f0 -> PrimaryExpression()
	 * f1 -> "<"
	 * f2 -> PrimaryExpression()
	 */
	public R visit(CompareExpression n) {
		R _ret=null;
		n.f0.accept(this);
		n.f1.accept(this);
		n.f2.accept(this);
		return _ret;
	}

	/**
	 * f0 -> PrimaryExpression()
	 * f1 -> "+"
	 * f2 -> PrimaryExpression()
	 */
	public R visit(PlusExpression n) {
		R _ret=null;
		n.f0.accept(this);
		n.f1.accept(this);
		n.f2.accept(this);
		return _ret;
	}

	/**
	 * f0 -> PrimaryExpression()
	 * f1 -> "-"
	 * f2 -> PrimaryExpression()
	 */
	public R visit(MinusExpression n) {
		R _ret=null;
		n.f0.accept(this);
		n.f1.accept(this);
		n.f2.accept(this);
		return _ret;
	}

	/**
	 * f0 -> PrimaryExpression()
	 * f1 -> "*"
	 * f2 -> PrimaryExpression()
	 */
	public R visit(TimesExpression n) {
		R _ret=null;
		n.f0.accept(this);
		n.f1.accept(this);
		n.f2.accept(this);
		return _ret;
	}

	/**
	 * f0 -> PrimaryExpression()
	 * f1 -> "["
	 * f2 -> PrimaryExpression()
	 * f3 -> "]"
	 */
	public R visit(ArrayLookup n) {
		R _ret=null;
		n.f0.accept(this);
		n.f1.accept(this);
		n.f2.accept(this);
		n.f3.accept(this);
		return _ret;
	}

	/**
	 * f0 -> Expression()
	 * f1 -> ( ExpressionRest() )*
	 */
	public R visit(ExpressionList n) {
		R _ret=null;
		n.f0.accept(this);
		n.f1.accept(this);
		return _ret;
	}

	/**
	 * f0 -> ","
	 * f1 -> Expression()
	 */
	public R visit(ExpressionRest n) {
		R _ret=null;
		n.f0.accept(this);
		n.f1.accept(this);
		return _ret;
	}

	/**
	 * f0 -> IntegerLiteral()
	 *       | TrueLiteral()
	 *       | FalseLiteral()
	 *       | VarRef()
	 *       | ThisExpression()
	 *       | ArrayAllocationExpression()
	 *       | AllocationExpression()
	 *       | NotExpression()
	 *       | BracketExpression()
	 */
	public R visit(PrimaryExpression n) {
		R _ret=null;
		n.f0.accept(this);
		return _ret;
	}

	/**
	 * f0 -> <INTEGER_LITERAL>
	 */
	public R visit(IntegerLiteral n) {
		R _ret=null;
		n.f0.accept(this);
		return _ret;
	}

	/**
	 * f0 -> "true"
	 */
	public R visit(TrueLiteral n) {
		R _ret=null;
		n.f0.accept(this);
		return _ret;
	}

	/**
	 * f0 -> "false"
	 */
	public R visit(FalseLiteral n) {
		R _ret=null;
		n.f0.accept(this);
		return _ret;
	}

	/**
	 * f0 -> <IDENTIFIER>
	 */
	public R visit(Identifier n) {
		R _ret=null;
		n.f0.accept(this);
		return _ret;
	}

	/**
	 * f0 -> "this"
	 */
	public R visit(ThisExpression n) {
		R _ret=null;
		n.f0.accept(this);
		return _ret;
	}

	/**
	 * f0 -> "new"
	 * f1 -> "int"
	 * f2 -> "["
	 * f3 -> Expression()
	 * f4 -> "]"
	 */
	public R visit(ArrayAllocationExpression n) {
		R _ret=null;
		n.f0.accept(this);
		n.f1.accept(this);
		n.f2.accept(this);
		n.f3.accept(this);
		n.f4.accept(this);
		return _ret;
	}

	/**
	 * f0 -> "new"
	 * f1 -> Identifier()
	 * f2 -> "("
	 * f3 -> ")"
	 */
	public R visit(AllocationExpression n) {

		R _ret=null;
		n.f0.accept(this);
		n.f1.accept(this);
		n.f2.accept(this);
		n.f3.accept(this);
		return _ret;
	}

	/**
	 * f0 -> "!"
	 * f1 -> Expression()
	 */
	public R visit(NotExpression n) {
		R _ret=null;
		n.f0.accept(this);
		n.f1.accept(this);
		return _ret;
	}

	/**
	 * f0 -> "("
	 * f1 -> Expression()
	 * f2 -> ")"
	 */
	public R visit(BracketExpression n) {
		R _ret=null;
		n.f0.accept(this);
		n.f1.accept(this);
		n.f2.accept(this);
		return _ret;
	}

	/**
	 * f0 -> DotExpression()
	 *       | Identifier()
	 */
	public R visit(VarRef n) {
		R _ret=null;
		n.f0.accept(this);
		return _ret;
	}

	/**
	 * f0 -> Identifier()
	 * f1 -> "."
	 * f2 -> Identifier()
	 */
	public R visit(DotExpression n) {
		R _ret=null;
		n.f0.accept(this);
		n.f1.accept(this);
		n.f2.accept(this);
		return _ret;
	}

	public void addNewVar(String var, String type){
		ConstraintCollection._var_map.put(this._class_name+"."+this._method_name
				+"."+var, type);
	}

	public String getVarType(String var){
		String _local_var_name = null;
		_local_var_name = ConstraintCollection._var_map.get(this._class_name+"."+this._method_name
				+"."+var);

		if(_local_var_name == null){
			_local_var_name = ConstraintCollection._var_map.get(this._class_name+".."+var);
		}
		return _local_var_name;
	}


	public List<String> filterByMethodName(List<String> list, String accept) {
		Vector<Node> _vector_typeDecl = this.goal_node.f1.nodes;
		List<String> _containerClass = new ArrayList<String>();

		for(String _class_name : list){
			for(Node _nd : _vector_typeDecl){
				Node _class_node = ((TypeDeclaration) _nd).f0.choice;

				if(_class_node instanceof ClassDeclaration){
					String _cls_name = ((ClassDeclaration) _class_node).f1.accept(ToStringVisitor.visitor);
					if(_cls_name.equals(_class_name) && containsMethod(((ClassDeclaration) _class_node).f4.nodes, accept)){
						_containerClass.add(_cls_name);
					}
				}

				else if(_class_node instanceof ClassExtendsDeclaration){
					String _cls_name = ((ClassExtendsDeclaration) _class_node).f1.accept(ToStringVisitor.visitor);
					if(_cls_name.equals(_class_name) && containsMethod(((ClassExtendsDeclaration) _class_node).f6.nodes, accept)){
						_containerClass.add(((ClassExtendsDeclaration) _class_node).f1.accept(ToStringVisitor.visitor));
					}
				}
			}		   
		}
		return _containerClass;
	}

	private boolean containsMethod(Vector<Node> nodes, String accept) {
		for(Node _nd : nodes){
			MethodDeclaration _method = (MethodDeclaration) _nd;
			if(_method.f2.accept(ToStringVisitor.visitor).equals(accept)){
				return true;
			}
		}
		return false;
	}

	public String getFullVarName(String _cls, String _met, String _var){
		return _cls+"."+_met+"."+_var;
	}
}
