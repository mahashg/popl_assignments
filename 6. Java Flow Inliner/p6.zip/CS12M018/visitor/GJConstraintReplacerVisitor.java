package visitor;

import java.util.Enumeration;
import java.util.List;

import constraints.ConstraintCollection;

import syntaxtree.AllocationExpression;
import syntaxtree.AndExpression;
import syntaxtree.ArrayAllocationExpression;
import syntaxtree.ArrayAssignmentStatement;
import syntaxtree.ArrayLookup;
import syntaxtree.ArrayType;
import syntaxtree.AssignmentStatement;
import syntaxtree.Block;
import syntaxtree.BooleanType;
import syntaxtree.BracketExpression;
import syntaxtree.ClassDeclaration;
import syntaxtree.ClassExtendsDeclaration;
import syntaxtree.CompareExpression;
import syntaxtree.DotExpression;
import syntaxtree.Expression;
import syntaxtree.ExpressionList;
import syntaxtree.ExpressionRest;
import syntaxtree.FalseLiteral;
import syntaxtree.FormalParameter;
import syntaxtree.FormalParameterList;
import syntaxtree.FormalParameterRest;
import syntaxtree.Goal;
import syntaxtree.Identifier;
import syntaxtree.IfStatement;
import syntaxtree.IntegerLiteral;
import syntaxtree.IntegerType;
import syntaxtree.MainClass;
import syntaxtree.MessageSendStatement;
import syntaxtree.MethodDeclaration;
import syntaxtree.MinusExpression;
import syntaxtree.Node;
import syntaxtree.NodeChoice;
import syntaxtree.NodeList;
import syntaxtree.NodeListOptional;
import syntaxtree.NodeOptional;
import syntaxtree.NodeSequence;
import syntaxtree.NodeToken;
import syntaxtree.NotExpression;
import syntaxtree.PlusExpression;
import syntaxtree.PrimaryExpression;
import syntaxtree.PrintStatement;
import syntaxtree.Statement;
import syntaxtree.ThisExpression;
import syntaxtree.TimesExpression;
import syntaxtree.TrueLiteral;
import syntaxtree.Type;
import syntaxtree.TypeDeclaration;
import syntaxtree.VarDeclaration;
import syntaxtree.VarRef;
import syntaxtree.WhileStatement;

public class GJConstraintReplacerVisitor implements GJNoArguVisitor<Node>{
	public List<Expression> expr_list;
	public List<FormalParameter> formal_list;
	public List<FormalParameter> formal_list_new;
	
	public String _class_name;
	public String _method_name;
	public Goal goal_node;
	//
	// Auto class visitors--probably don't need to be overridden.
	//
	public Node visit(NodeList n) {
		NodeList _ret=new NodeList();
		//  int _count=0;
		for ( Enumeration<Node> e = n.elements(); e.hasMoreElements(); ) {
			_ret.addNode(e.nextElement().accept(this));
			//   _count++;
		}
		return _ret;
	}

	public Node visit(NodeListOptional n) {
		NodeListOptional _nlo = new NodeListOptional();
		if ( n.present() ) {
			
			for ( Enumeration<Node> e = n.elements(); e.hasMoreElements(); ) {
				_nlo.addNode(e.nextElement().accept(this));
			}
		}
		return _nlo;
	}

	public Node visit(NodeOptional n) {
		NodeOptional _no = new NodeOptional();
		if ( n.present() )
			_no.addNode(n.node.accept(this));
		return _no;
		
	}

	public Node visit(NodeSequence n) {
		NodeSequence _ret=new NodeSequence(1);
		// int _count=0;
		for ( Enumeration<Node> e = n.elements(); e.hasMoreElements(); ) {
			_ret.addNode(e.nextElement().accept(this));
			//   _count++;
		}
		return _ret;
	}

	public Node visit(NodeToken n) { return n; }

	//
	// User-generated visitor methods below
	//

	/**
	 * f0 -> MainClass()
	 * f1 -> ( TypeDeclaration() )*
	 * f2 -> <EOF>
	 */
	public Node visit(Goal n) {

		Node _ret=null;
		this.goal_node = n;

		n.f0.accept(this);
		n.f1.accept(this);
		n.f2.accept(this);

		return _ret;
	}

	/**
	 * f0 -> "class"
	 * f1 -> Identifier()
	 * f2 -> "{"
	 * f3 -> "public"
	 * f4 -> "static"
	 * f5 -> "void"
	 * f6 -> "main"
	 * f7 -> "("
	 * f8 -> "String"
	 * f9 -> "["
	 * f10 -> "]"
	 * f11 -> Identifier()
	 * f12 -> ")"
	 * f13 -> "{"
	 * f14 -> "new"
	 * f15 -> Identifier()
	 * f16 -> "("
	 * f17 -> ")"
	 * f18 -> "."
	 * f19 -> Identifier()
	 * f20 -> "("
	 * f21 -> ( ExpressionList() )?
	 * f22 -> ")"
	 * f23 -> ";"
	 * f24 -> "}"
	 * f25 -> "}"
	 */
	public Node visit(MainClass n) {
		Node _ret=null;
		n.f0.accept(this);
		n.f1.accept(this);
		n.f2.accept(this);
		n.f3.accept(this);
		n.f4.accept(this);
		n.f5.accept(this);
		n.f6.accept(this);
		n.f7.accept(this);
		n.f8.accept(this);
		n.f9.accept(this);
		n.f10.accept(this);
		n.f11.accept(this);
		n.f12.accept(this);
		n.f13.accept(this);
		n.f14.accept(this);
		n.f15.accept(this);
		n.f16.accept(this);
		n.f17.accept(this);
		n.f18.accept(this);
		n.f19.accept(this);
		n.f20.accept(this);
		n.f21.accept(this);
		n.f22.accept(this);
		n.f23.accept(this);
		n.f24.accept(this);
		n.f25.accept(this);
		return _ret;
	}

	/**
	 * f0 -> ClassDeclaration()
	 *       | ClassExtendsDeclaration()
	 */
	public Node visit(TypeDeclaration n) {
		Node _ret=null;
		
		return new TypeDeclaration(new NodeChoice(n.f0.accept(this)));
	}

	/**
	 * f0 -> "class"
	 * f1 -> Identifier()
	 * f2 -> "{"
	 * f3 -> ( VarDeclaration() )*
	 * f4 -> ( MethodDeclaration() )*
	 * f5 -> "}"
	 */
	public Node visit(ClassDeclaration n) {

		Node _ret=null;
		
		this._class_name = n.f1.accept(ToStringVisitor.visitor);
		Node n0 = n.f0.accept(this);
		Node n1 = n.f1.accept(this);
		Node n2 = n.f2.accept(this);
		Node n3 = n.f3.accept(this);
		Node n4 = n.f4.accept(this);
		Node n5 = n.f5.accept(this);
		
		this._class_name = "";
		return new ClassDeclaration(nodeToIdentifier(n1), new NodeListOptional(n3), new NodeListOptional(n4));
	}

	/**
	 * f0 -> "class"
	 * f1 -> Identifier()
	 * f2 -> "extends"
	 * f3 -> Identifier()
	 * f4 -> "{"
	 * f5 -> ( VarDeclaration() )*
	 * f6 -> ( MethodDeclaration() )*
	 * f7 -> "}"
	 */
	public Node visit(ClassExtendsDeclaration n) {
		
		this._class_name = n.f1.accept(ToStringVisitor.visitor);
		Node n0 = n.f0.accept(this);
		Node n1 = n.f1.accept(this);
		Node n2 = n.f2.accept(this);
		Node n3 = n.f3.accept(this);
		Node n4 = n.f4.accept(this);
		Node n5 = n.f5.accept(this);
		Node n6 = n.f6.accept(this);
		Node n7 = n.f7.accept(this);
		
		this._class_name = "";
		
		return new ClassExtendsDeclaration(nodeToIdentifier(n1), nodeToIdentifier(n3), new NodeListOptional(n5), new NodeListOptional(n6));
	}

	/**
	 * f0 -> Type()
	 * f1 -> Identifier()
	 * f2 -> ";"
	 */
	public Node visit(VarDeclaration n) {

		Node _ret=null;
		n.f0.accept(this);
		n.f1.accept(this);
		n.f2.accept(this);
		return n;
	}

	/**
	 * f0 -> "public"
	 * f1 -> "void"
	 * f2 -> Identifier()
	 * f3 -> "("
	 * f4 -> ( FormalParameterList() )?
	 * f5 -> ")"
	 * f6 -> "{"
	 * f7 -> ( VarDeclaration() )*
	 * f8 -> ( Statement() )*
	 * f9 -> "}"
	 */
	public Node visit(MethodDeclaration n) {
		this._method_name = n.f2.accept(ToStringVisitor.visitor);
		
		Node _ret=null;      
		Node n0 = n.f0.accept(this);
		Node n1 = n.f1.accept(this);
		Node n2 = n.f2.accept(this);
		Node n3 = n.f3.accept(this);
		Node n4 = n.f4.accept(this);
		Node n5 = n.f5.accept(this);
		Node n6 = n.f6.accept(this);
		Node n7 = n.f7.accept(this);
		Node n8 = n.f8.accept(this);
		Node n9 = n.f9.accept(this);

		this._method_name = "";
		return new MethodDeclaration(nodeToIdentifier(n2), (NodeOptional)n4, (NodeListOptional)n7, (NodeListOptional)n8);
	}

	/**
	 * f0 -> FormalParameter()
	 * f1 -> ( FormalParameterRest() )*
	 */
	public Node visit(FormalParameterList n) {
		Node _ret=null;
		n.f0.accept(this);
		n.f1.accept(this);
		return n;
	}

	/**
	 * f0 -> Type()
	 * f1 -> Identifier()
	 */
	public Node visit(FormalParameter n) {
		Node _ret=null;

		n.f0.accept(this);
		n.f1.accept(this);
		return n;
	}

	/**
	 * f0 -> ","
	 * f1 -> FormalParameter()
	 */
	public Node visit(FormalParameterRest n) {
		Node _ret=null;
		n.f0.accept(this);
		n.f1.accept(this);
		return n;
	}

	/**
	 * f0 -> ArrayType()
	 *       | BooleanType()
	 *       | IntegerType()
	 *       | Identifier()
	 */
	public Node visit(Type n) {
		Node _ret=null;
		
		return new Type(new NodeChoice(n.f0.accept(this)));
	}

	/**
	 * f0 -> "int"
	 * f1 -> "["
	 * f2 -> "]"
	 */
	public Node visit(ArrayType n) {
		Node _ret=null;
		n.f0.accept(this);
		n.f1.accept(this);
		n.f2.accept(this);
		return n;
	}

	/**
	 * f0 -> "boolean"
	 */
	public Node visit(BooleanType n) {
		Node _ret=null;
		n.f0.accept(this);
		return n;
	}

	/**
	 * f0 -> "int"
	 */
	public Node visit(IntegerType n) {
		Node _ret=null;
		n.f0.accept(this);
		return n;
	}

	/**
	 * f0 -> Block()
	 *       | AssignmentStatement()
	 *       | ArrayAssignmentStatement()
	 *       | IfStatement()
	 *       | WhileStatement()
	 *       | PrintStatement()
	 *       | MessageSendStatement()
	 */
	public Node visit(Statement n) {
		Statement _stmt = new Statement(new NodeChoice(n.f0.accept(this)));		
		return _stmt;
	}

	/**
	 * f0 -> "{"
	 * f1 -> ( Statement() )*
	 * f2 -> "}"
	 */
	public Node visit(Block n) {
		Node _ret=null;
		Node n0 = n.f0.accept(this);
		Node n1 = n.f1.accept(this);
		Node n2 = n.f2.accept(this);
		return new Block((NodeListOptional)n1);
	}

	/**
	 * f0 -> VarRef()
	 * f1 -> "="
	 * f2 -> Expression()
	 * f3 -> ";"
	 */
	public Node visit(AssignmentStatement n) {
		
		Node n0 = n.f0.accept(this);
		Node n1 = n.f1.accept(this);
		Node n2 = n.f2.accept(this);
		Node n3 = n.f3.accept(this);

		return new AssignmentStatement(new VarRef(new NodeChoice(n0)), (Expression)n2);
	}

	/**
	 * f0 -> Identifier()
	 * f1 -> "["
	 * f2 -> Expression()
	 * f3 -> "]"
	 * f4 -> "="
	 * f5 -> Expression()
	 * f6 -> ";"
	 */
	public Node visit(ArrayAssignmentStatement n) {
		
		Node n0 = n.f0.accept(this);
		Node n1 = n.f1.accept(this);
		Node n2 = n.f2.accept(this);
		Node n3 = n.f3.accept(this);
		Node n4 = n.f4.accept(this);
		Node n5 = n.f5.accept(this);
		Node n6 = n.f6.accept(this);
		return new ArrayAssignmentStatement(nodeToIdentifier(n0), new Expression(new NodeChoice(n2)), (Expression)n5);
	}

	/**
	 * f0 -> "if"
	 * f1 -> "("
	 * f2 -> Expression()
	 * f3 -> ")"
	 * f4 -> Statement()
	 * f5 -> "else"
	 * f6 -> Statement()
	 */
	public Node visit(IfStatement n) {
		Node _ret=null;
		Node n0 = n.f0.accept(this);
		Node n1 = n.f1.accept(this);
		Node n2 = n.f2.accept(this);
		Node n3 = n.f3.accept(this);
		Node n4 = n.f4.accept(this);
		Node n5 = n.f5.accept(this);
		Node n6 = n.f6.accept(this);
		
		return new IfStatement(new Expression(new NodeChoice(n2)), new Statement(new NodeChoice(n4)), new Statement(new NodeChoice(n6)));
	}

	/**
	 * f0 -> "while"
	 * f1 -> "("
	 * f2 -> Expression()
	 * f3 -> ")"
	 * f4 -> Statement()
	 */
	public Node visit(WhileStatement n) {
		
		Node n0 = n.f0.accept(this);
		Node n1 = n.f1.accept(this);
		Node n2 = n.f2.accept(this);
		Node n3 = n.f3.accept(this);
		Node n4 = n.f4.accept(this);
		return new WhileStatement(new Expression(new NodeChoice(n2)), new Statement(new NodeChoice(n4)));
	}

	/**
	 * f0 -> "System.out.println"
	 * f1 -> "("
	 * f2 -> Expression()
	 * f3 -> ")"
	 * f4 -> ";"
	 */
	public Node visit(PrintStatement n) {
		Node _ret=null;
		Node n0 = n.f0.accept(this);
		Node n1 = n.f1.accept(this);
		Node n2 = n.f2.accept(this);
		Node n3 = n.f3.accept(this);
		Node n4 = n.f4.accept(this);
		return new PrintStatement(new Expression(new NodeChoice(n2)));
	}

	/**
	 * f0 -> Identifier()
	 * f1 -> "."
	 * f2 -> Identifier()
	 * f3 -> "("
	 * f4 -> ( ExpressionList() )?
	 * f5 -> ")"
	 * f6 -> ";"
	 */
	public Node visit(MessageSendStatement n) {
		Node _ret=null;
		
		Node n0 = n.f0.accept(this);
		Node n1 = n.f1.accept(this);
		Node n2 = n.f2.accept(this);
		Node n3 = n.f3.accept(this);
		Node n4 = n.f4.accept(this);
		Node n5 = n.f5.accept(this);
		Node n6 = n.f6.accept(this);

		return new MessageSendStatement(nodeToIdentifier(n0), nodeToIdentifier(n2), (NodeOptional)n4);
	}

	/**
	 * f0 -> AndExpression()
	 *       | CompareExpression()
	 *       | PlusExpression()
	 *       | MinusExpression()
	 *       | TimesExpression()
	 *       | ArrayLookup()
	 *       | PrimaryExpression()
	 */
	public Node visit(Expression n) {		
		
		return new Expression(new NodeChoice(n.f0.accept(this)));
	}

	/**
	 * f0 -> PrimaryExpression()
	 * f1 -> "&"
	 * f2 -> PrimaryExpression()
	 */
	public Node visit(AndExpression n) {
		//Node _ret=null;
		Node n0 = n.f0.accept(this);
		Node n1 = n.f1.accept(this);
		Node n2 = n.f2.accept(this);
		
		return new AndExpression(new PrimaryExpression(new NodeChoice(n0)), new PrimaryExpression(new NodeChoice(n2)));
	}

	/**
	 * f0 -> PrimaryExpression()
	 * f1 -> "<"
	 * f2 -> PrimaryExpression()
	 */
	public Node visit(CompareExpression n) {
		Node n0 = n.f0.accept(this);
		Node n1 = n.f1.accept(this);
		Node n2 = n.f2.accept(this);
		
		return new CompareExpression(new PrimaryExpression(new NodeChoice(n0)), new PrimaryExpression(new NodeChoice(n2)));
	}

	/**
	 * f0 -> PrimaryExpression()
	 * f1 -> "+"
	 * f2 -> PrimaryExpression()
	 */
	public Node visit(PlusExpression n) {
		Node n0 = n.f0.accept(this);
		Node n1 = n.f1.accept(this);
		Node n2 = n.f2.accept(this);
		
		return new PlusExpression(new PrimaryExpression(new NodeChoice(n0)), new PrimaryExpression(new NodeChoice(n2)));
	}

	/**
	 * f0 -> PrimaryExpression()
	 * f1 -> "-"
	 * f2 -> PrimaryExpression()
	 */
	public Node visit(MinusExpression n) {
		Node n0 = n.f0.accept(this);
		Node n1 = n.f1.accept(this);
		Node n2 = n.f2.accept(this);
		
		return new MinusExpression(new PrimaryExpression(new NodeChoice(n0)), new PrimaryExpression(new NodeChoice(n2)));
	}

	/**
	 * f0 -> PrimaryExpression()
	 * f1 -> "*"
	 * f2 -> PrimaryExpression()
	 */
	public Node visit(TimesExpression n) {
		Node n0 = n.f0.accept(this);
		Node n1 = n.f1.accept(this);
		Node n2 = n.f2.accept(this);
		
		return new TimesExpression(new PrimaryExpression(new NodeChoice(n0)), new PrimaryExpression(new NodeChoice(n2)));
	}

	/**
	 * f0 -> PrimaryExpression()
	 * f1 -> "["
	 * f2 -> PrimaryExpression()
	 * f3 -> "]"
	 */
	public Node visit(ArrayLookup n) {
		Node n0 = n.f0.accept(this);
		Node n1 = n.f1.accept(this);
		Node n2 = n.f2.accept(this);
		
		return new ArrayLookup(new PrimaryExpression(new NodeChoice(n0)), new PrimaryExpression(new NodeChoice(n2)));
	}

	/**
	 * f0 -> Expression()
	 * f1 -> ( ExpressionRest() )*
	 */
	public Node visit(ExpressionList n) {
		//Node _ret=null;
		Node n0 = n.f0.accept(this);
		Node n1 = n.f1.accept(this);
		
		return new ExpressionList(new Expression(new NodeChoice(n0)), (NodeListOptional) n1);
	}

	/**
	 * f0 -> ","
	 * f1 -> Expression()
	 */
	public Node visit(ExpressionRest n) {
		Node _ret=null;
		Node n0 = n.f0.accept(this);
		Node n1 = n.f1.accept(this);
		return new ExpressionRest(new Expression(new NodeChoice(n1)));
	}

	/**
	 * f0 -> IntegerLiteral()
	 *       | TrueLiteral()
	 *       | FalseLiteral()
	 *       | VarRef()
	 *       | ThisExpression()
	 *       | ArrayAllocationExpression()
	 *       | AllocationExpression()
	 *       | NotExpression()
	 *       | BracketExpression()
	 */
	public Node visit(PrimaryExpression n) {
		
		return n.f0.accept(this);
	}

	/**
	 * f0 -> <INTEGER_LITERAL>
	 */
	public Node visit(IntegerLiteral n) {
		
		return n;
	}

	/**
	 * f0 -> "true"
	 */
	public Node visit(TrueLiteral n) {
		return n;
	}

	/**
	 * f0 -> "false"
	 */
	public Node visit(FalseLiteral n) {
		return n;
	}

	/**
	 * f0 -> <IDENTIFIER>
	 */
	public Node visit(Identifier n) {
		String _identifier_name = n.accept(ToStringVisitor.visitor); /*getFullVarName(_class_name, _method_name, */

		for(int i=0 ; i<this.formal_list.size() ; ++i){
			FormalParameter _param = this.formal_list.get(i);
			FormalParameter _param_new = this.formal_list_new.get(i);
			//Expression _expr = this.expr_list.get(i);
			
			if(_identifier_name.equals(_param.f1.accept(ToStringVisitor.visitor))){

				return _param_new.f1; //new Identifier(new NodeToken(_expr.accept(ToStringVisitor.visitor)));
			}
		}
		
		return n;
	}

	/**
	 * f0 -> "this"
	 */
	public Node visit(ThisExpression n) {
		String _identifier_name = "this";
		for(int i=0 ; i<this.formal_list.size() ; ++i){
			FormalParameter _param = this.formal_list.get(i);
			FormalParameter _param_new = this.formal_list_new.get(i);
			
			if(_identifier_name.equals(_param.f1.accept(ToStringVisitor.visitor))){
				return _param_new.f1;
			}
		}
		return nodeToIdentifier(n);
	}

	/**
	 * f0 -> "new"
	 * f1 -> "int"
	 * f2 -> "["
	 * f3 -> Expression()
	 * f4 -> "]"
	 */
	public Node visit(ArrayAllocationExpression n) {
		
		Node n0 = n.f0.accept(this);
		Node n1 = n.f1.accept(this);
		Node n2 = n.f2.accept(this);
		Node n3 = n.f3.accept(this);
		Node n4 = n.f4.accept(this);
		
		
		return new ArrayAllocationExpression(new Expression(new NodeChoice(n3)));
	}

	/**
	 * f0 -> "new"
	 * f1 -> Identifier()
	 * f2 -> "("
	 * f3 -> ")"
	 */
	public Node visit(AllocationExpression n) {

		Node _ret=null;
		Node n0 = n.f0.accept(this);
		Node n1 = n.f1.accept(this);
		Node n2 = n.f2.accept(this);
		Node n3 = n.f3.accept(this);
		return new AllocationExpression(nodeToIdentifier(n1));
	}

	/**
	 * f0 -> "!"
	 * f1 -> Expression()
	 */
	public Node visit(NotExpression n) {

		Node n0 = n.f0.accept(this);
		Node n1 = n.f1.accept(this);
		return new NotExpression(new Expression(new NodeChoice(n1)));
	}

	/**
	 * f0 -> "("
	 * f1 -> Expression()
	 * f2 -> ")"
	 */
	public Node visit(BracketExpression n) {
		Node n0 = n.f0.accept(this);
		Node n1= n.f1.accept(this);
		Node n2 = n.f2.accept(this);
		return new BracketExpression(new Expression(new NodeChoice(n1)));
	}

	/**
	 * f0 -> DotExpression()
	 *       | Identifier()
	 */
	public Node visit(VarRef n) {
		
		return new VarRef(new NodeChoice(n.f0.accept(this)));
	}

	/**
	 * f0 -> Identifier()
	 * f1 -> "."
	 * f2 -> Identifier()
	 */
	public Node visit(DotExpression n) {
		Node _ret=null;
		Node n0=null;
		String _identifier_name = n.f0.accept(ToStringVisitor.visitor);
		for(int i=0 ; i<this.formal_list.size() ; ++i){
			FormalParameter _param = this.formal_list.get(i);
			FormalParameter _param_new = this.formal_list_new.get(i);
			
			if(_identifier_name.trim().equals(_param.f1.accept(ToStringVisitor.visitor).trim())){				
				n0 = _param_new.f1;			
			}
		}
		
		if(n0 == null){
			n0 = n.f0;
		}
		
		return new DotExpression(nodeToIdentifier(n0), n.f2);
	}
	
	private Identifier nodeToIdentifier(Node nd){
		//TODO: extra space might occur
		return new Identifier(new NodeToken(nd.accept(ToStringVisitor.visitor)));
	}
	
	public String getFullVarName(String _cls, String _met, String _var){
			   if(ConstraintCollection._var_map.containsKey(_cls+"."+_met+"."+_var)){
				   return _cls+"."+_met+"."+_var;
			   }else if(ConstraintCollection._var_map.containsKey(_cls+".."+_var)){
				   return _cls+".."+_var;
			   }else {
			   }
			   return _cls+"."+_met+"."+_var;
		}
}
