import java.util.ArrayList;

import syntaxtree.Node;
import visitor.GJConstraintGeneratorVisitor;
import visitor.GJConstraintInliner;
import visitor.GJConstraintSolverVisitor;
import visitor.ToStringVisitor;
import constraints.ConstraintCollection;

public class P6 {
	public static void main(String[] args) {
		try {
			
			new MicroJavaParser(System.in);
			Node root = MicroJavaParser.Goal();
			
			// 1. Generated all constraints
			root.accept(new GJConstraintGeneratorVisitor<String>());
		
			// 2. Generate table
			root.accept(new GJConstraintSolverVisitor<String>());
		
			// 3. Solve constraints
			ConstraintCollection.solveConstraints();
			
			
			//4. do method inlining without touching mutually recursive or recursive methods.
			GJConstraintInliner inliner = new GJConstraintInliner();
			ArrayList<ArrayList<Boolean>> _arr = ConstraintCollection.create2DArray();
			while(!_arr.isEmpty()){
				int mark = -1;
				for(int i=0 ; i<_arr.size() ; ++i){
					ArrayList<Boolean> _arr_inner = _arr.get(i);
					boolean found = true;
					for(boolean bool_val : _arr_inner){
						if(bool_val){ found = false; }
					}
					if(found){
						// CHOSE THE METHOD WHICH HAS NO METHOD CALL INSIDE IT
						mark = i;
						break;
					}
				}
				if(mark == -1){
					for(int i=0 ; i<_arr.size() ; ++i){
						boolean found = true;						
						for(int j=0 ; j<_arr.size() ; ++j){
							if(_arr.get(j).get(i)){ found = false; }
						}
						if(found) {mark = i; break;}
					}
				}
				if(mark != -1){
					// DO INLINE FOR THIS METHOD TYPE ONLY
					// IN THIS ITERATION
					inliner._method_to_expand = ConstraintCollection.method_list.get(mark);
					root = root.accept(inliner);
					_arr.remove(mark);
					for(int i=0 ; i<_arr.size() ; ++i){
						_arr.get(i).remove(mark);
					}
				}else {
					break;
				}

			}
			
			System.out.println(root.accept(ToStringVisitor.visitor));
		} catch (Exception e) {
			System.out.println(e.toString());
		}
	}
}
