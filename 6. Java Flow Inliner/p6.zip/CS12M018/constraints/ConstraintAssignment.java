package constraints;

import java.util.Map;

public class ConstraintAssignment extends ConstraintGeneric {
	public String subset;
	public String superset;
	
	@Override
	public String toString() {
		return "ConstraintAssignment [subset=" + subset + ", superset=" + superset + "]";
	}

	@Override
	public void process() {
		// add an edge subset -> superset
		ConstraintCollection.addNewDependency(subset, superset);
		
		if(ConstraintCollection._var_type_map.containsKey(subset)){
			Map<String, Boolean> _map = ConstraintCollection._var_type_map.get(subset);

			for (String _str : _map.keySet()){
				// only if true
				if(_map.get(_str)){
					propagate(superset, _str);
				}
			}
		}
	}
	
}