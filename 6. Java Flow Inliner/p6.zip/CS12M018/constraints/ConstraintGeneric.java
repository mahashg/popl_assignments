package constraints;

import java.util.ArrayList;
import java.util.List;


public abstract class ConstraintGeneric {

	public abstract void process();
	
	public void propagate(String set, String element) {
		
		if(!ConstraintCollection.getVarTypeValue(set, element)){
			// 1.
			ConstraintCollection.putVarTypeValue(set, element, true);
		
			// 2.
			List<String> _list = ConstraintCollection.getAllDependency(set);
			for(String _str : _list){
				propagate(_str, element);
			}
			
			// 3. 
			List<ConstraintGeneric> _pending = ConstraintCollection.getPendingConstraints(set, element);
			for(ConstraintGeneric _cons : _pending){
				_cons.process();
			}
			
			// 4.
			ConstraintCollection.getPendingConstraints(set, element).clear();
		}
		
		
	}

}
