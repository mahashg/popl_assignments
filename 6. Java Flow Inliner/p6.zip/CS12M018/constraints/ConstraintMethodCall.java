package constraints;

public class ConstraintMethodCall extends ConstraintGeneric {
	public String subset;
	public String superset;
	public String element;
	public String set;
	
	@Override
	public String toString() {
		return "ConstraintMethodCall [subset=" + subset + ", superset=" + superset + ", element=" + element + ", set=" + set + "]";
	}

	@Override
	public void process() {
		// TODO Auto-generated method stub
		ConstraintAssignment _assign = new ConstraintAssignment();
		_assign.subset = subset;
		_assign.superset = superset;
		
		if(ConstraintCollection.getVarTypeValue(set, element)){
			_assign.process();
		}else {
			//this.pendingConstraints.add(_assign);
			ConstraintCollection.addPendingConstraint(set, element, _assign);
		}
	}
}
