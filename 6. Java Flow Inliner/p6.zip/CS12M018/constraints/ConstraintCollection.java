package constraints;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


public class ConstraintCollection {
	public static Map<String, String> _var_map = new HashMap<String, String>();
	public static Map<String, List<String>> _cls_hier_map = new HashMap<String, List<String>>();
	public static List<ConstraintGeneric> constraitList = new ArrayList<ConstraintGeneric>();
	public static Map<String, Map<String, Boolean>> _var_type_map = new HashMap<String, Map<String, Boolean>>();
	public static Map<String, Map<String, List<ConstraintGeneric>>> pendingConstraints = new HashMap<String, Map<String,List<ConstraintGeneric>>>();
	public static Map<String, List<String>> _var_dependency_list = new HashMap<String, List<String>>();

	public static List<String> method_list = new ArrayList<String>();
	public static Map<String, List<String>> _method_call_list = new HashMap<String, List<String>>();
	
	public static void reset() {
		_var_map.clear();
		_cls_hier_map.clear();
		constraitList.clear();
		_var_type_map.clear();
		pendingConstraints.clear();
		_var_dependency_list.clear();
		method_list.clear();
		_method_call_list.clear();
		
	}
	
	public static ArrayList<ArrayList<Boolean>> create2DArray(){
		ArrayList<ArrayList<Boolean>> _arr = new ArrayList<ArrayList<Boolean>>();
		
		for(int i=0 ; i<method_list.size() ; ++i){
			ArrayList<Boolean> _list = new ArrayList<Boolean>();
			for(int j=0 ; j<method_list.size() ; ++j){
				_list.add(false);
			}
			_arr.add(_list);
		}
		
		for(String _str : _method_call_list.keySet()){
			for(String _str2 : _method_call_list.get(_str)){
				int i = method_list.indexOf(_str);
				int j= method_list.indexOf(_str2);
				_arr.get(i).remove(j);
				_arr.get(i).add(j, true);
			}
		}
		
		/** TODO: Printer
		for(int i=0 ; i<_arr.size() ; ++i){
			for(int j=0 ; j<_arr.get(i).size() ; ++j){
				System.out.print(_arr.get(i).get(j)+" ");
			}
			System.out.println();
		}*/
		
		return _arr;
	}
	public static void addToMethodCallList(String callingMethod, String calledMethod){
		List<String> _list= _method_call_list.get(callingMethod);
		if(_list == null){
			_list = new ArrayList<String>();
			_method_call_list.put(callingMethod, _list);
		}
		
		_list.add(calledMethod);
	}
	
	public static void addNewDependency(String X, String Y){
		List<String> _list = _var_dependency_list.get(X);
		
		if(_list == null){
			_list = new ArrayList<String>();
			_var_dependency_list.put(X, _list);
		}
		_list.add(Y);
		
	}
	
	public static List<String> getAllDependency(String X){
		if(_var_dependency_list.containsKey(X)){
			return _var_dependency_list.get(X);
		}
		
		return new ArrayList<String>();
	}
	public static void addConstraint(ConstraintGeneric _constraint) {
		constraitList.add(_constraint);		
	}

	public static void solveConstraints() {
		for(ConstraintGeneric _cons : constraitList){
			_cons.process();
		}
		
	}

	public static void addPendingConstraint(String set, String element, ConstraintAssignment _assign) {
		
		Map<String, List<ConstraintGeneric>> _mp_outer = pendingConstraints.get(set);
		if(_mp_outer == null){
			_mp_outer = new HashMap<String, List<ConstraintGeneric>>();
			pendingConstraints.put(set, _mp_outer);
		}
		
		List<ConstraintGeneric> _mp_inner = _mp_outer.get(element);
		if(_mp_inner == null){
			_mp_inner = new ArrayList<ConstraintGeneric>();
			_mp_outer.put(element, _mp_inner);
		}
		
		_mp_inner.add(_assign);
	}
	
	public static List<ConstraintGeneric> getPendingConstraints(String set, String element){
		Map<String, List<ConstraintGeneric>> _mp_outer = pendingConstraints.get(set);
		if(_mp_outer == null){
			return new ArrayList<ConstraintGeneric>();
		}
		
		List<ConstraintGeneric> _cg = _mp_outer.get(element);
		if(_cg == null){
			return new ArrayList<ConstraintGeneric>();
		}
		return _cg;
	}

	public static boolean getVarTypeValue(String set, String element) {
		// TODO Auto-generated method stub
		Map<String, Boolean> _mp = _var_type_map.get(set);
		if(_mp == null){
			return false;
		}
		
		if(_mp.containsKey(element)){
			return _mp.get(element);
		}

		return false;
	}

	public static void putVarTypeValue(String set, String element, boolean b) {
		// TODO Auto-generated method stub
		Map<String, Boolean> _map = _var_type_map.get(set);
		if(_map == null){
			_map = new HashMap<String, Boolean>();
			_var_type_map.put(set, _map);
		}
		
		_map.put(element, b);
	}	
}
