package constraints;

public class ConstraintNewType extends ConstraintGeneric {
	public String element;
	public String set;
	
	@Override
	public String toString() {
		return "ConstraintNewType [element=" + element + ", set=" + set + "]";
	}

	@Override
	public void process() {
		propagate(set, element);		
	}
		
}
